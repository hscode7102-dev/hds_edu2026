import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

/**
 * [초급 · 4교시 · 실습 5] JSON으로 답받기 (Structured Output) + 검증
 *
 * 3교시와 달라진 점
 *   - 규칙은 system 메시지(prompts/team_system.txt), 의뢰 문장은 user 메시지로 분리
 *   - response_format에 JSON Schema(schemas/team_routing.schema.json)를 넣어 "이 모양으로만 답하라"고 강제
 *   - 받은 JSON을 Java가 한 번 더 검사 → 이상하면 사람 검토(REVIEW)로 돌림
 *
 * 받는 JSON 예: {"team":"손사지원팀","reason":"실손 청구 심사 화면","confidence":0.92,"needs_review":false}
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch4_structured/N06Structured.java
 *
 * ✏️ 해 볼 것
 *   1. REVIEW_THRESHOLD를 0.9로 올리면 REVIEW가 몇 건으로 늘어나는지 확인
 *   2. checkResult()에 "reason이 비어 있으면 오류" 검사를 직접 추가 (TODO 표시)
 */
public class N06Structured {

    static final double REVIEW_THRESHOLD = 0.70;   // ✏️ 이 값보다 자신 없으면 사람이 검토

    static final List<String> ALLOWED_TEAMS = Arrays.asList(
            "장기계약팀", "장기유지팀", "손사지원팀", "자동차보험팀", "자동차보상팀", "일반보험팀",
            "마케팅팀", "정보계지원팀", "콜센터팀", "홈페이지모바일팀", "개발지원팀", "REVIEW");

    public static void main(String[] args) throws Exception {
        String systemPrompt = readFile("prompts/team_system.txt");
        JsonObject schema = JsonParser.parseString(readFile("schemas/team_routing.schema.json")).getAsJsonObject();
        JsonArray requests = JsonParser.parseString(readFile("data/requests.json")).getAsJsonArray();

        int correct = 0;
        for (JsonElement element : requests) {
            JsonObject req = element.getAsJsonObject();
            String answer = ask(systemPrompt, "<request>\n" + req.get("text").getAsString() + "\n</request>", schema);

            // 1) JSON 문자열 → JsonObject
            JsonObject result;
            try {
                result = JsonParser.parseString(answer).getAsJsonObject();
            } catch (Exception e) {
                System.out.println("X " + req.get("id").getAsString() + " JSON이 아님 → REVIEW : " + answer);
                continue;
            }

            // 2) 내용 검사 (모델을 믿지 않고 Java가 확인)
            String error = checkResult(result);
            String team;
            if (error != null) {
                team = "REVIEW";
                System.out.println("  [검사 실패] " + error);
            } else if (result.get("confidence").getAsDouble() < REVIEW_THRESHOLD) {
                team = "REVIEW";                         // 3) 자신 없으면 사람에게
            } else {
                team = result.get("team").getAsString();
            }

            boolean ok = team.equals(req.get("expected").getAsString());
            if (ok) correct++;
            System.out.println((ok ? "O " : "X ") + req.get("id").getAsString() + "  " + team
                    + "  (신뢰도 " + result.get("confidence") + ")  " + (result.has("reason") ? result.get("reason").getAsString() : ""));
        }
        System.out.println("→ 정확도 " + correct + "/" + requests.size());
    }

    /** 문제가 있으면 오류 메시지, 없으면 null */
    static String checkResult(JsonObject r) {
        if (!r.has("team") || !ALLOWED_TEAMS.contains(r.get("team").getAsString())) {
            return "허용되지 않은 팀: " + r.get("team");
        }
        if (!r.has("confidence")) return "confidence 없음";
        double c = r.get("confidence").getAsDouble();
        if (c < 0.0 || c > 1.0) return "confidence가 0~1 범위를 벗어남: " + c;
        // TODO ✏️ reason이 없거나 빈 문자열이면 "reason 없음"을 반환하도록 추가
        return null;
    }

    static String ask(String systemPrompt, String userText, JsonObject schema) throws Exception {
        String apiKey = System.getenv("API_KEY");
        String baseUrl = System.getenv("BASE_URL") != null ? System.getenv("BASE_URL") : "https://openrouter.ai/api/v1";
        String model = System.getenv("MODEL") != null ? System.getenv("MODEL") : "google/gemma-4-26b-a4b-it";

        JsonObject system = new JsonObject();
        system.addProperty("role", "system");             // 규칙
        system.addProperty("content", systemPrompt);
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");                 // 데이터
        user.addProperty("content", userText);
        JsonArray messages = new JsonArray();
        messages.add(system);
        messages.add(user);

        // response_format = { "type":"json_schema", "json_schema": { "name":..., "strict":true, "schema":{...} } }
        JsonObject jsonSchema = new JsonObject();
        jsonSchema.addProperty("name", "team_routing");
        jsonSchema.addProperty("strict", true);
        jsonSchema.add("schema", schema);
        JsonObject responseFormat = new JsonObject();
        responseFormat.addProperty("type", "json_schema");
        responseFormat.add("json_schema", jsonSchema);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);
        body.addProperty("max_tokens", 300);
        body.add("response_format", responseFormat);
        if (baseUrl.contains("openrouter.ai")) {
            // OpenRouter 전용: 스키마를 지원하는 제공사로만 보내라는 옵션 (사내 서버에는 보내지 않음)
            JsonObject provider = new JsonObject();
            provider.addProperty("require_parameters", true);
            body.add("provider", provider);
        }

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode() + " : " + response.body());
        }
        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString().trim();
    }

    static String readFile(String path) throws Exception {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }
}
