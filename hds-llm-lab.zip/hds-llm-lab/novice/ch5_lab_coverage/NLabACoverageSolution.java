import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * [초급 · 5교시 · 종합실습 Ⅰ · 정답 코드] 설계사 포탈 — 고객 보장 분석
 *
 * 설계사가 상담 전에 "이 고객은 어떤 보장이 얼마나 있고, 무엇이 비어 있나"를 한눈에 보는 기능
 *
 *   ① 고객의 특약 목록 읽기 ............ Java   (data/customers.json)
 *   ② 특약명 → 표준 보장 분류 매핑 ...... LLM    (예: "암진단비(유사암 제외)" → CANCER)
 *   ③ 빠진 특약·이상한 분류 검사 ........ Java
 *   ④ 분류별 금액 합계, 보장 공백 찾기 ... Java   (계산은 LLM에게 맡기지 않음)
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch5_lab_coverage/NLabACoverageSolution.java C002
 *       (고객ID: C001, C002, C003 — 생략하면 C001)
 */
public class NLabACoverageSolution {

    public static void main(String[] args) throws Exception {
        String customerId = args.length > 0 ? args[0] : "C001";

        // ① 고객의 특약 목록 읽기 : riderId → 특약 정보
        JsonObject customer = findCustomer(customerId);
        Map<String, JsonObject> riders = new LinkedHashMap<>();
        for (JsonElement c : customer.getAsJsonArray("contracts")) {
            for (JsonElement r : c.getAsJsonObject().getAsJsonArray("riders")) {
                JsonObject rider = r.getAsJsonObject();
                riders.put(rider.get("riderId").getAsString(), rider);
            }
        }
        System.out.println("고객 " + customerId + " / 특약 " + riders.size() + "개");

        // ② LLM에게 매핑 요청
        JsonArray categories = JsonParser.parseString(readFile("data/coverage_categories.json")).getAsJsonArray();
        String systemPrompt = readFile("prompts/coverage_system.txt").replace("{{CATEGORIES}}", categoryText(categories));
        String userMessage = buildUserMessage(riders);
        System.out.println("\n[LLM에 보내는 특약 목록]\n" + userMessage);

        JsonObject answer = JsonParser.parseString(askJson(systemPrompt, userMessage)).getAsJsonObject();
        JsonArray mappings = answer.getAsJsonArray("mappings");

        // ③ 검사 : 모든 특약이 매핑됐는가?
        Map<String, String> categoryOf = new LinkedHashMap<>();   // riderId → 분류 코드
        for (JsonElement m : mappings) {
            JsonObject o = m.getAsJsonObject();
            categoryOf.put(o.get("riderId").getAsString(), o.get("category").getAsString());
        }
        for (String riderId : riders.keySet()) {
            if (!categoryOf.containsKey(riderId)) {
                System.out.println("[검사] 매핑이 빠진 특약: " + riderId + " → 설계사가 직접 확인");
            }
        }

        // ④ 분류별 금액 합계 + 보장 공백
        System.out.println("\n== 설계사 화면용 결과 ==");
        for (JsonElement e : categories) {
            String code = e.getAsJsonObject().get("code").getAsString();
            String name = e.getAsJsonObject().get("name").getAsString();
            long total = 0;
            for (Map.Entry<String, String> entry : categoryOf.entrySet()) {
                if (code.equals(entry.getValue()) && riders.containsKey(entry.getKey())) {
                    total += riders.get(entry.getKey()).get("amount").getAsLong();
                }
            }
            if (total == 0) System.out.println("- " + name + " : (가입 없음) ← 보장 공백");
            else System.out.println("- " + name + " : " + String.format("%,d", total) + "원");
        }
        for (Map.Entry<String, String> entry : categoryOf.entrySet()) {
            if (entry.getValue().equals("UNKNOWN")) {
                System.out.println("[확인 필요] " + entry.getKey() + " — AI가 분류하지 못한 특약");
            }
        }
        System.out.println("※ AI 매핑 결과를 포함함. 상담 전 원 계약 내용을 확인할 것");
    }

    /** 특약 목록을 "riderId | 특약명" 한 줄씩으로 만듦 (금액은 매핑에 필요 없으므로 보내지 않음) */
    static String buildUserMessage(Map<String, JsonObject> riders) {
        StringBuilder sb = new StringBuilder("특약 목록:\n<riders>\n");
        for (String riderId : riders.keySet()) {
            String name = riders.get(riderId).get("name").getAsString();
            sb.append(riderId).append(" | ").append(name).append("\n");
        }
        sb.append("</riders>");
        return sb.toString();
    }

    // ---------------- 아래는 준비된 코드 (수정하지 않아도 됨) ----------------

    static JsonObject findCustomer(String customerId) throws Exception {
        for (JsonElement e : JsonParser.parseString(readFile("data/customers.json")).getAsJsonArray()) {
            if (e.getAsJsonObject().get("customerId").getAsString().equals(customerId)) return e.getAsJsonObject();
        }
        throw new IllegalArgumentException("고객 없음: " + customerId);
    }

    static String categoryText(JsonArray categories) {
        StringBuilder sb = new StringBuilder();
        for (JsonElement e : categories) {
            JsonObject c = e.getAsJsonObject();
            sb.append("- ").append(c.get("code").getAsString()).append(": ").append(c.get("name").getAsString())
              .append(" — ").append(c.get("desc").getAsString()).append("\n");
        }
        return sb.append("- UNKNOWN: 특약 이름만으로 판단 불가").toString();
    }

    /** system + user 메시지를 보내고, JSON Schema로 형식을 강제한 답변 문자열을 돌려줌 */
    static String askJson(String systemPrompt, String userText) throws Exception {
        String apiKey = System.getenv("API_KEY");
        String baseUrl = System.getenv("BASE_URL") != null ? System.getenv("BASE_URL") : "https://openrouter.ai/api/v1";
        String model = System.getenv("MODEL") != null ? System.getenv("MODEL") : "google/gemma-4-26b-a4b-it";

        JsonArray messages = new JsonArray();
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content", systemPrompt);
        messages.add(system);
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", userText);
        messages.add(user);

        JsonObject jsonSchema = new JsonObject();
        jsonSchema.addProperty("name", "coverage_mapping");
        jsonSchema.addProperty("strict", true);
        jsonSchema.add("schema", JsonParser.parseString(readFile("schemas/coverage_mapping.schema.json")));
        JsonObject responseFormat = new JsonObject();
        responseFormat.addProperty("type", "json_schema");
        responseFormat.add("json_schema", jsonSchema);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);
        body.addProperty("max_tokens", 800);
        body.add("response_format", responseFormat);
        if (baseUrl.contains("openrouter.ai")) {
            JsonObject provider = new JsonObject();
            provider.addProperty("require_parameters", true);
            body.add("provider", provider);
        }

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(90))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode() + " : " + response.body());
        }
        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString().trim();
    }

    static String readFile(String path) throws Exception {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }
}
