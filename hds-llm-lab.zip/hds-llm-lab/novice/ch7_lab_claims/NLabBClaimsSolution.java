import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * [초급 · 7교시 · 종합실습 Ⅱ · 정답 코드] 보상 포탈 — 실손 청구 심사 보조
 *
 * 원칙: 정해진 규칙 = Java 코드 / 서류 해석 = LLM / 지급 여부 최종 판단 = 사람(보상 담당자)
 *
 *   ① 약관 찾기 ...... Java : 가입일에 맞는 약관 버전(3세대/4세대)의 조항을 골라 LLM에게 줌 (간이 RAG)
 *   ② 서류 해석 ...... LLM  : 진료 유형·진단명·확인 필요 사항 + 근거 조항 ID
 *   ③ 인용 검사 ...... Java : LLM이 댄 조항 ID가 실제로 준 조항인지 확인 (그럴듯한 거짓 근거 차단)
 *   ④ 규칙 점검 ...... Java : 가입 직후 청구, 미용 목적, 통원 한도 등
 *   ⑤ 담당자 화면 .... 지급 여부는 쓰지 않음
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch7_lab_claims/NLabBClaimsSolution.java
 *       (data/claims.json의 청구 3건: CL-001 도수치료, CL-002 입원, CL-003 피부과 레이저)
 */
public class NLabBClaimsSolution {

    public static void main(String[] args) throws Exception {
        JsonObject policy = JsonParser.parseString(readFile("data/policy_clauses.json")).getAsJsonObject();
        JsonArray claims = JsonParser.parseString(readFile("data/claims.json")).getAsJsonArray();
        String systemPrompt = readFile("prompts/claim_system.txt");

        for (JsonElement element : claims) {
            JsonObject claim = element.getAsJsonObject();
            JsonObject contract = claim.getAsJsonObject("contract");
            System.out.println("\n========== " + claim.get("claimId").getAsString() + " ==========");

            // ① 약관 찾기 : 가입일이 적용 기간 안에 있는 버전
            JsonObject version = findVersion(policy, contract.get("joinDate").getAsString());
            Map<String, String> clauses = new LinkedHashMap<>();   // 조항 ID → 제목: 본문
            for (JsonElement c : version.getAsJsonArray("clauses")) {
                JsonObject o = c.getAsJsonObject();
                clauses.put(o.get("id").getAsString(), o.get("title").getAsString() + ": " + o.get("text").getAsString());
            }
            System.out.println("적용 약관: " + version.get("version").getAsString() + " (가입일 " + contract.get("joinDate").getAsString() + ")");

            // ② 서류 해석 (LLM)
            StringBuilder user = new StringBuilder();
            user.append("가입일 ").append(contract.get("joinDate").getAsString())
                .append(" / 청구일 ").append(claim.get("claimDate").getAsString())
                .append(" / 청구금액 ").append(claim.get("amount").getAsLong()).append("원\n");
            user.append("<documents>\n").append(claim.get("documents").getAsString()).append("\n</documents>\n<clauses>\n");
            for (Map.Entry<String, String> c : clauses.entrySet()) {
                user.append("[").append(c.getKey()).append("] ").append(c.getValue()).append("\n");
            }
            user.append("</clauses>");
            JsonObject ai = JsonParser.parseString(askJson(systemPrompt, user.toString())).getAsJsonObject();

            // ③ 인용 검사
            List<String> cited = new ArrayList<>();
            for (JsonElement id : ai.getAsJsonArray("citedClauses")) {
                String clauseId = id.getAsString();
                if (clauses.containsKey(clauseId)) cited.add(clauseId + " " + clauses.get(clauseId));
                else cited.add(clauseId + " ← 제공하지 않은 조항! AI가 지어낸 근거일 수 있음");
            }

            // ④ 규칙 점검
            List<String> flags = checkRules(claim, ai.get("treatmentType").getAsString());

            // ⑤ 담당자 화면
            System.out.println("진료 유형   : " + ai.get("treatmentType").getAsString());
            System.out.println("진단명      : " + ai.get("diagnosis").getAsString());
            System.out.println("근거 조항   : " + cited);
            System.out.println("AI 확인사항 : " + ai.get("concerns"));
            System.out.println("규칙 점검   : " + flags);
            System.out.println("판단        : 담당자 확인 필요 (AI는 지급 여부를 판단하지 않음)");
        }
    }

    /** 정해진 규칙은 Java로 확인 (실습용 가상 기준) */
    static List<String> checkRules(JsonObject claim, String treatmentType) {
        List<String> flags = new ArrayList<>();
        LocalDate joinDate = LocalDate.parse(claim.getAsJsonObject("contract").get("joinDate").getAsString());
        LocalDate claimDate = LocalDate.parse(claim.get("claimDate").getAsString());
        long amount = claim.get("amount").getAsLong();

        // 규칙 1: 가입 후 90일 이내 청구 → 가입 전 병력 알림(고지) 확인
        long days = ChronoUnit.DAYS.between(joinDate, claimDate);
        if (days <= 90) {
            flags.add("가입 후 " + days + "일 만의 청구 — 고지 의무 확인");
        }

        // 규칙 2: 미용·예방 목적은 보상하지 않는 손해일 수 있음
        if (treatmentType.equals("미용_또는_예방")) flags.add("미용·예방 목적 — 보상 제외 조항 확인");

        // 규칙 3: 통원 1회 청구가 20만 원을 넘으면 한도 확인
        if (treatmentType.equals("통원") && amount > 200000) flags.add("통원 20만 원 초과 — 회당 한도 확인");

        // 규칙 4: 도수치료는 연간 횟수 누적 확인
        if (treatmentType.equals("비급여_도수치료")) flags.add("도수치료 — 연간 횟수·한도 누적 확인");
        return flags;
    }

    // ---------------- 아래는 준비된 코드 (수정하지 않아도 됨) ----------------

    /** 가입일이 effectiveFrom ~ effectiveTo 안에 있는 약관 버전 */
    static JsonObject findVersion(JsonObject policy, String joinDate) {
        LocalDate join = LocalDate.parse(joinDate);
        for (JsonElement e : policy.getAsJsonArray("versions")) {
            JsonObject v = e.getAsJsonObject();
            LocalDate from = LocalDate.parse(v.get("effectiveFrom").getAsString());
            LocalDate to = LocalDate.parse(v.get("effectiveTo").getAsString());
            if (!join.isBefore(from) && !join.isAfter(to)) return v;
        }
        throw new IllegalArgumentException("가입일에 맞는 약관 없음: " + joinDate);
    }

    static String askJson(String systemPrompt, String userText) throws Exception {
        String apiKey = System.getenv("API_KEY");
        String baseUrl = System.getenv("BASE_URL") != null ? System.getenv("BASE_URL") : "https://openrouter.ai/api/v1";
        String model = System.getenv("MODEL") != null ? System.getenv("MODEL") : "google/gemma-4-26b-a4b-it";

        JsonArray messages = new JsonArray();
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content", systemPrompt);
        messages.add(system);
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", userText);
        messages.add(user);

        JsonObject jsonSchema = new JsonObject();
        jsonSchema.addProperty("name", "claim_review");
        jsonSchema.addProperty("strict", true);
        jsonSchema.add("schema", JsonParser.parseString(readFile("schemas/claim_review.schema.json")));
        JsonObject responseFormat = new JsonObject();
        responseFormat.addProperty("type", "json_schema");
        responseFormat.add("json_schema", jsonSchema);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);
        body.addProperty("max_tokens", 600);
        body.add("response_format", responseFormat);
        if (baseUrl.contains("openrouter.ai")) {
            JsonObject provider = new JsonObject();
            provider.addProperty("require_parameters", true);
            body.add("provider", provider);
        }

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(90))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode() + " : " + response.body());
        }
        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString().trim();
    }

    static String readFile(String path) throws Exception {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }
}
