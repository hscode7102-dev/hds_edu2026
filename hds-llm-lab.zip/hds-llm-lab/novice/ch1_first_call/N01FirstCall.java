import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * [초급 · 1교시 · 실습 1-1] LLM에 처음으로 질문하기
 *
 * 하는 일은 딱 세 가지
 *   ① 요청 JSON 만들기   ② HTTP POST로 보내기   ③ 응답 JSON에서 답변 꺼내기
 *
 * 실행: VS Code에서 main 위의 Run 클릭
 *   또는 java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch1_first_call/N01FirstCall.java
 *
 * ✏️ 해 볼 것
 *   1. QUESTION을 다른 질문으로 바꿔 실행
 *   2. "role": "system" 메시지를 추가해 말투를 지정 (아래 주석 참고)
 */
public class N01FirstCall {

    // ✏️ 질문을 바꿔 보세요
    static final String QUESTION = "실손보험이 무엇인지 두 문장으로 설명해줘.";

    public static void main(String[] args) throws Exception {
        // 접속 정보는 환경변수에서 읽음 (키를 코드에 쓰지 않음)
        String apiKey = System.getenv("API_KEY");
        String baseUrl = "https://openrouter.ai/api/v1";
        String model = "google/gemma-4-26b-a4b-it";
        if (System.getenv("BASE_URL") != null) baseUrl = System.getenv("BASE_URL");
        if (System.getenv("MODEL") != null) model = System.getenv("MODEL");

        // ① 요청 JSON 만들기
        //    { "model": "...", "messages": [ {"role":"user","content":"질문"} ], "max_tokens": 300 }
        JsonObject userMessage = new JsonObject();
        userMessage.addProperty("role", "user");          // 누가 말했는가: user(사람)
        userMessage.addProperty("content", QUESTION);     // 무엇을 말했는가

        JsonArray messages = new JsonArray();
        // ✏️ 2번 과제: 아래 세 줄의 주석(//)을 지우면 시스템 메시지가 추가됨
        // JsonObject systemMessage = new JsonObject();
        // systemMessage.addProperty("role", "system"); systemMessage.addProperty("content", "초등학생도 알아듣게 답한다.");
        // messages.add(systemMessage);
        messages.add(userMessage);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("max_tokens", 300);              // 답변 최대 길이(토큰)

        System.out.println("[보낸 요청] " + body);

        // ② HTTP POST로 보내기
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))                       // 60초 안에 답이 없으면 포기
                .header("Authorization", "Bearer " + apiKey)           // 인증: API 키
                .header("Content-Type", "application/json")            // 보내는 형식: JSON
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));

        System.out.println("[HTTP 상태] " + response.statusCode() + "  (200이면 성공)");
        if (response.statusCode() != 200) {
            System.out.println("[오류 내용] " + response.body());
            return;
        }

        // ③ 응답 JSON에서 답변 꺼내기 : choices[0].message.content
        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        JsonObject firstChoice = json.getAsJsonArray("choices").get(0).getAsJsonObject();
        String answer = firstChoice.getAsJsonObject("message").get("content").getAsString();

        // 토큰 사용량 : usage.prompt_tokens(입력), usage.completion_tokens(출력) → 비용 계산 기준
        JsonObject usage = json.getAsJsonObject("usage");

        System.out.println("\n[답변]\n" + answer);
        System.out.println("\n[토큰] 입력 " + usage.get("prompt_tokens") + " / 출력 " + usage.get("completion_tokens"));
    }
}
