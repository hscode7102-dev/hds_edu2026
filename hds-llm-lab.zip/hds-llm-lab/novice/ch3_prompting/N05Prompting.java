import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;

/**
 * [초급 · 3교시 · 실습 4] 전산작업의뢰 → 담당 팀 분류 : Zero-shot과 Few-shot 비교
 *
 * - Zero-shot : 규칙만 주고 분류         (prompts/team_zero_shot.txt)
 * - Few-shot  : 규칙 + 예시 5개를 주고 분류 (prompts/team_few_shot.txt)
 * - 같은 의뢰 10건(data/requests.json)을 두 방식으로 분류해 맞힌 개수를 비교
 *
 * 프롬프트는 .txt 파일에 있음 → 코드를 고치지 않고 프롬프트만 바꿔 실험할 수 있음
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch3_prompting/N05Prompting.java
 *
 * ✏️ 해 볼 것
 *   1. 틀린 의뢰를 찾아 prompts/team_zero_shot.txt의 팀 설명을 보강한 뒤 다시 실행
 *   2. 예시가 늘어날수록 입력 토큰이 얼마나 늘어나는지 확인
 */
public class N05Prompting {

    static final String[] TEAMS = {
            "장기계약팀", "장기유지팀", "손사지원팀", "자동차보험팀", "자동차보상팀", "일반보험팀",
            "마케팅팀", "정보계지원팀", "콜센터팀", "홈페이지모바일팀", "개발지원팀", "REVIEW"};

    public static void main(String[] args) throws Exception {
        String zeroShot = readFile("prompts/team_zero_shot.txt");
        String fewShot = readFile("prompts/team_few_shot.txt");
        JsonArray requests = JsonParser.parseString(readFile("data/requests.json")).getAsJsonArray();

        runAll("Zero-shot", zeroShot, requests);
        runAll("Few-shot", fewShot, requests);
    }

    static void runAll(String label, String promptTemplate, JsonArray requests) throws Exception {
        System.out.println("\n== " + label + " ==");
        int correct = 0;
        int inputTokens = 0;

        for (JsonElement element : requests) {
            JsonObject req = element.getAsJsonObject();
            String text = req.get("text").getAsString();
            String expected = req.get("expected").getAsString();

            // 템플릿의 {{REQUEST_TEXT}} 자리에 의뢰 문장을 끼워 넣음
            String prompt = promptTemplate.replace("{{REQUEST_TEXT}}", text);
            JsonObject res = ask(prompt);
            String answer = res.getAsJsonArray("choices").get(0).getAsJsonObject()
                    .getAsJsonObject("message").get("content").getAsString();
            inputTokens += res.getAsJsonObject("usage").get("prompt_tokens").getAsInt();

            String team = findTeam(answer);
            boolean ok = team.equals(expected);
            if (ok) correct++;
            System.out.println((ok ? "O " : "X ") + req.get("id").getAsString()
                    + "  기대=" + expected + "  결과=" + team);
        }
        System.out.println("→ " + correct + "/" + requests.size() + "건 정답, 건당 입력 토큰 약 " + (inputTokens / requests.size()));
    }

    /** 모델 답변에서 허용 팀 이름을 찾음. 형식이 들쭉날쭉해도 팀명만 있으면 찾아냄 (4교시에서 JSON으로 개선) */
    static String findTeam(String answer) {
        for (String team : TEAMS) {
            if (answer.contains(team)) return team;
        }
        return "(팀명 없음)";
    }

    static JsonObject ask(String prompt) throws Exception {
        String apiKey = System.getenv("API_KEY");
        String baseUrl = System.getenv("BASE_URL") != null ? System.getenv("BASE_URL") : "https://openrouter.ai/api/v1";
        String model = System.getenv("MODEL") != null ? System.getenv("MODEL") : "google/gemma-4-26b-a4b-it";

        JsonObject userMessage = new JsonObject();
        userMessage.addProperty("role", "user");
        userMessage.addProperty("content", prompt);
        JsonArray messages = new JsonArray();
        messages.add(userMessage);
        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);   // 분류는 매번 같은 답이 나오도록 0
        body.addProperty("max_tokens", 100);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode() + " : " + response.body());
        }
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    /** 파일을 UTF-8로 읽음 (실습 폴더 C:\hds-llm-lab 기준 경로) */
    static String readFile(String path) throws Exception {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }
}
