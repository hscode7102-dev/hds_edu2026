import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * [초급 · 6교시 · 하네스] 프롬프트를 "감"이 아니라 "점수"로 고치기
 *
 * 하네스 = 프롬프트를 시험 보는 장치
 *   - 시험지 : data/testset_team_routing.json (20문제, 태그: 대표·경계·반례·정보부족·주입 등)
 *   - 채점   : 기대 팀과 같으면 정답, 태그별 정답률도 계산
 *   - 성적표 : logs/summary_<버전>.json 저장 → Git에 커밋해 버전별로 비교
 *
 * 고치는 순서: ① 실행 → ② 틀린 문제 확인 → ③ 프롬프트 수정 → ④ VERSION 올려 다시 실행 → ⑤ 점수 비교 후 커밋
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch6_harness/NHarness.java
 *
 * ✏️ 해 볼 것: prompts/team_system.txt를 복사해 prompts/team_system_v2.txt를 만들고 규칙을 고친 뒤
 *             PROMPT_FILE과 VERSION을 바꿔 다시 실행 → 두 성적표 비교
 */
public class NHarness {

    static final String PROMPT_FILE = "prompts/team_system.txt";   // ✏️ 측정할 프롬프트
    static final String VERSION = "v1";                            // ✏️ 성적표 이름

    public static void main(String[] args) throws Exception {
        String systemPrompt = readFile(PROMPT_FILE);
        JsonArray tests = JsonParser.parseString(readFile("data/testset_team_routing.json")).getAsJsonArray();

        int correct = 0;
        Map<String, int[]> byTag = new LinkedHashMap<>();   // 태그 → {맞힌 수, 전체 수}
        JsonArray wrongList = new JsonArray();

        System.out.println("프롬프트 " + PROMPT_FILE + " (" + VERSION + ") / 문제 " + tests.size() + "개");
        for (JsonElement element : tests) {
            JsonObject t = element.getAsJsonObject();
            String id = t.get("id").getAsString();
            String tag = t.get("tag").getAsString();
            String expected = t.get("expected").getAsString();

            String team;
            try {
                String answer = ask(systemPrompt, "<request>\n" + t.get("text").getAsString() + "\n</request>");
                team = JsonParser.parseString(answer).getAsJsonObject().get("team").getAsString();
            } catch (Exception e) {
                team = "(오류: " + e.getMessage() + ")";
            }

            int[] score = byTag.computeIfAbsent(tag, k -> new int[2]);
            score[1]++;
            if (team.equals(expected)) {
                correct++;
                score[0]++;
                System.out.println("O " + id + " [" + tag + "] " + team);
            } else {
                System.out.println("X " + id + " [" + tag + "] 기대=" + expected + " 결과=" + team);
                JsonObject wrong = new JsonObject();
                wrong.addProperty("id", id);
                wrong.addProperty("tag", tag);
                wrong.addProperty("expected", expected);
                wrong.addProperty("actual", team);
                wrongList.add(wrong);
            }
            Thread.sleep(300);   // 30명이 동시에 돌리므로 호출 사이에 잠깐 쉼
        }

        // 성적표
        JsonObject summary = new JsonObject();
        summary.addProperty("version", VERSION);
        summary.addProperty("promptFile", PROMPT_FILE);
        summary.addProperty("accuracy", correct + "/" + tests.size());
        JsonObject tagScore = new JsonObject();
        for (Map.Entry<String, int[]> e : byTag.entrySet()) {
            tagScore.addProperty(e.getKey(), e.getValue()[0] + "/" + e.getValue()[1]);
        }
        summary.add("byTag", tagScore);
        summary.add("wrong", wrongList);

        String text = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create().toJson(summary);
        Files.createDirectories(Paths.get("logs"));
        Files.write(Paths.get("logs", "summary_" + VERSION + ".json"), text.getBytes(StandardCharsets.UTF_8));
        System.out.println("\n== 성적표 (logs/summary_" + VERSION + ".json) ==\n" + text);
    }

    /** N06Structured와 같은 방식: 시스템 프롬프트 + JSON Schema */
    static String ask(String systemPrompt, String userText) throws Exception {
        String apiKey = System.getenv("API_KEY");
        String baseUrl = System.getenv("BASE_URL") != null ? System.getenv("BASE_URL") : "https://openrouter.ai/api/v1";
        String model = System.getenv("MODEL") != null ? System.getenv("MODEL") : "google/gemma-4-26b-a4b-it";

        JsonArray messages = new JsonArray();
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content", systemPrompt);
        messages.add(system);
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", userText);
        messages.add(user);

        JsonObject jsonSchema = new JsonObject();
        jsonSchema.addProperty("name", "team_routing");
        jsonSchema.addProperty("strict", true);
        jsonSchema.add("schema", JsonParser.parseString(readFile("schemas/team_routing.schema.json")));
        JsonObject responseFormat = new JsonObject();
        responseFormat.addProperty("type", "json_schema");
        responseFormat.add("json_schema", jsonSchema);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);
        body.addProperty("max_tokens", 300);
        body.add("response_format", responseFormat);
        if (baseUrl.contains("openrouter.ai")) {
            JsonObject provider = new JsonObject();
            provider.addProperty("require_parameters", true);
            body.add("provider", provider);
        }

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode());
        }
        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString().trim();
    }

    static String readFile(String path) throws Exception {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }
}
