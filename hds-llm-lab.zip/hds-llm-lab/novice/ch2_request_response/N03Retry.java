import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalTime;

/**
 * [초급 · 2교시 · 실습 3] 실패하면 잠깐 쉬었다가 다시 시도하기
 *
 * 규칙 (외우기 쉬운 버전)
 *   - 429(호출 몰림), 500번대(서버 오류), 시간 초과 → 다시 시도할 가치가 있음
 *   - 400·401·404 (요청·키·주소가 틀림)               → 몇 번을 다시 해도 실패 → 바로 중단
 *   - 쉬는 시간은 1초 → 2초 … 로 두 배씩 늘림 (지수 백오프)
 *   - 매 시도를 한 줄 로그로 남김 → 나중에 원인 추적
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch2_request_response/N03Retry.java
 *       인자 bad-model 을 주면 없는 모델 이름으로 호출 → 400(잘못된 모델 ID)에서 바로 중단되는 모습 확인
 */
public class N03Retry {

    static final int MAX_ATTEMPTS = 3;    // 최대 시도 횟수

    public static void main(String[] args) throws Exception {
        String model = System.getenv("MODEL") != null ? System.getenv("MODEL") : "google/gemma-4-26b-a4b-it";
        if (args.length > 0 && args[0].equals("bad-model")) model = "no-such/model";

        String answer = askWithRetry("보험료와 보험금의 차이를 한 문장으로 설명해줘.", model);
        System.out.println("\n[최종 결과] " + answer);
    }

    static String askWithRetry(String question, String model) throws Exception {
        long waitMs = 1000;   // 처음 쉬는 시간 1초

        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            int status;
            String responseBody;
            try {
                HttpResponse<String> response = send(question, model);
                status = response.statusCode();
                responseBody = response.body();
            } catch (java.io.IOException e) {          // 시간 초과·네트워크 끊김
                status = -1;
                responseBody = e.toString();
            }
            log(attempt, status);

            if (status == 200) {
                JsonObject json = JsonParser.parseString(responseBody).getAsJsonObject();
                return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                        .getAsJsonObject("message").get("content").getAsString();
            }

            boolean retryable = (status == 429 || status >= 500 || status == -1);
            if (!retryable) {
                return "다시 시도해도 소용없는 오류(HTTP " + status + ") → 요청 내용·키·모델명 확인: " + responseBody;
            }
            if (attempt < MAX_ATTEMPTS) {
                System.out.println("  → " + waitMs + "ms 쉬고 다시 시도");
                Thread.sleep(waitMs);
                waitMs = waitMs * 2;                   // 1초 → 2초 → 4초 …
            }
        }
        return MAX_ATTEMPTS + "번 모두 실패 → 사용자에게 '잠시 후 다시 시도' 안내";
    }

    /** 한 줄 로그: 시각, 시도 번호, 상태 코드 (API 키·질문 원문은 남기지 않음) */
    static void log(int attempt, int status) {
        System.out.println("[LOG] time=" + LocalTime.now().withNano(0) + " attempt=" + attempt + " status=" + status);
    }

    static HttpResponse<String> send(String question, String model) throws Exception {
        String apiKey = System.getenv("API_KEY");
        String baseUrl = System.getenv("BASE_URL") != null ? System.getenv("BASE_URL") : "https://openrouter.ai/api/v1";

        JsonObject userMessage = new JsonObject();
        userMessage.addProperty("role", "user");
        userMessage.addProperty("content", question);
        JsonArray messages = new JsonArray();
        messages.add(userMessage);
        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("max_tokens", 200);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        return HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
    }
}
