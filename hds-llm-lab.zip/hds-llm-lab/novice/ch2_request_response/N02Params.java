import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * [초급 · 2교시 · 실습 2] 파라미터를 바꾸면 무엇이 달라지나
 *
 * 실험 1) temperature : 0이면 거의 같은 답, 높을수록 답이 흔들림
 * 실험 2) max_tokens  : 너무 작으면 답이 잘리고 finish_reason이 "length"가 됨
 * 실험 3) 출력 계약    : "팀명만 답하라"처럼 출력을 제한하면 출력 토큰(=비용·시간)이 줄어듦
 *
 * 1교시 코드와 달라진 점: 호출 부분을 ask() 메서드로 묶어 여러 번 부를 수 있게 함
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch2_request_response/N02Params.java
 *
 * ✏️ 해 볼 것: TEMPERATURES 값, 실험 2의 max_tokens 값을 바꿔 다시 실행
 */
public class N02Params {

    static final double[] TEMPERATURES = {0.0, 1.2};   // ✏️ 0.7, 1.5 같은 값도 넣어 보기

    public static void main(String[] args) throws Exception {
        // 답이 여러 개 나올 수 있는 질문이어야 temperature 차이가 보임
        String question = "실손보험 광고 문구를 15자 이내로 하나만 지어줘. 문구만 답해.";

        System.out.println("== 실험 1: temperature ==");
        for (double t : TEMPERATURES) {
            System.out.println("temperature " + t);
            for (int i = 1; i <= 3; i++) {
                JsonObject res = ask(question, t, 40);
                System.out.println("  " + i + "회차: " + answerOf(res));
            }
        }

        System.out.println("\n== 실험 2: max_tokens를 아주 작게 ==");
        JsonObject cut = ask("실손보험 청구 절차를 단계별로 자세히 설명해줘.", 0.0, 15);   // ✏️ 15를 500으로
        System.out.println("답변: " + answerOf(cut));
        System.out.println("finish_reason: " + finishReasonOf(cut) + "  ← length면 잘린 것, stop이면 끝까지 답한 것");

        System.out.println("\n== 실험 3: 출력 계약으로 토큰 줄이기 ==");
        JsonObject a = ask("다음 의뢰가 어느 팀 업무인지 자세히 분석해 주세요: 자동차 대물 보상 지급 화면 계산 오류", 0.0, 500);
        JsonObject b = ask("다음 의뢰의 담당 팀명만 답하라. 다른 말은 쓰지 마라.\n"
                + "허용 팀: 자동차보험팀, 자동차보상팀, 일반보험팀\n"
                + "의뢰: 자동차 대물 보상 지급 화면 계산 오류", 0.0, 500);
        System.out.println("자세히 분석해 달라고 함 → 출력 토큰 " + outputTokensOf(a));
        System.out.println("팀명만 답하라고 함     → 출력 토큰 " + outputTokensOf(b) + " / 답변: " + answerOf(b));
    }

    /** 질문 하나를 보내고 응답 JSON 전체를 돌려줌 */
    static JsonObject ask(String question, double temperature, int maxTokens) throws Exception {
        String apiKey = System.getenv("API_KEY");
        String baseUrl = System.getenv("BASE_URL") != null ? System.getenv("BASE_URL") : "https://openrouter.ai/api/v1";
        String model = System.getenv("MODEL") != null ? System.getenv("MODEL") : "google/gemma-4-26b-a4b-it";

        JsonObject userMessage = new JsonObject();
        userMessage.addProperty("role", "user");
        userMessage.addProperty("content", question);
        JsonArray messages = new JsonArray();
        messages.add(userMessage);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", temperature);   // 답의 무작위성
        body.addProperty("max_tokens", maxTokens);      // 답변 최대 길이

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode() + " : " + response.body());
        }
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    static String answerOf(JsonObject res) {
        JsonObject message = res.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
        if (message.get("content").isJsonNull()) return "(빈 답변)";
        return message.get("content").getAsString().trim();
    }

    static String finishReasonOf(JsonObject res) {
        return res.getAsJsonArray("choices").get(0).getAsJsonObject().get("finish_reason").toString();
    }

    static int outputTokensOf(JsonObject res) {
        return res.getAsJsonObject("usage").get("completion_tokens").getAsInt();
    }
}
