import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.Console;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * [초급 · 2교시 · 선택 실습(참고용)] 아주 간단한 챗봇 — 대화 이력은 Java가 들고 다닌다
 *   ※ 수업 중에는 진행하지 않음. 복습·여유 시간에 실행해 보는 참고 코드
 *
 * LLM은 이전 대화를 기억하지 못함 (1교시 '무상태')
 * → 챗봇은 지금까지의 대화(messages)를 Java가 리스트로 모아 두었다가, 질문할 때마다 '전부' 다시 보냄
 *
 *   messages = [ system(역할) , user1 , assistant1 , user2 , assistant2 , ... , 이번 질문 ]
 *
 * 실행: VS Code에서 main 위의 Run 클릭 → 아래 터미널에 질문 입력 (끝내려면 exit)
 *   또는 java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch2_request_response/N04Chatbot.java
 *
 * ✏️ 해 볼 것
 *   1. "제 이름은 홍길동이에요" → "제 이름이 뭐였죠?" 순서로 물어보기 (기억하는 것처럼 보임)
 *   2. 아래 ③ 줄을 주석(//) 처리하고 다시 1번을 해 보기 → 이제 기억하지 못함
 *   3. 대화가 길어질수록 '입력 토큰'이 계속 늘어나는 것 확인 (= 비용·속도 증가)
 *   4. SYSTEM_PROMPT를 바꿔 말투·역할 바꿔 보기
 */
public class N04Chatbot {

    // ✏️ 챗봇의 역할 (매 요청 맨 앞에 붙음)
    static final String SYSTEM_PROMPT = "너는 보험 용어를 쉽게 설명하는 도우미다. 3문장 이내로 답한다.";

    public static void main(String[] args) throws Exception {
        JsonArray messages = new JsonArray();          // 대화 이력 — 이것이 챗봇의 '기억'
        messages.add(message("system", SYSTEM_PROMPT));

        System.out.println("보험 용어 도우미입니다. 끝내려면 exit 를 입력하세요.");
        while (true) {
            System.out.print("\n나> ");
            String question = readLine();
            if (question == null || question.trim().equalsIgnoreCase("exit")) break;
            if (question.trim().isEmpty()) continue;

            messages.add(message("user", question));               // ① 내 질문을 이력에 추가
            JsonObject res = ask(messages);                        // ② 이력 '전체'를 보냄
            String answer = res.getAsJsonArray("choices").get(0).getAsJsonObject()
                    .getAsJsonObject("message").get("content").getAsString().trim();
            messages.add(message("assistant", answer));            // ③ AI 답변도 이력에 추가 (✏️ 2번 과제)

            int inputTokens = res.getAsJsonObject("usage").get("prompt_tokens").getAsInt();
            System.out.println("AI> " + answer);
            System.out.println("    (이번 요청: 메시지 " + (messages.size() - 1) + "개 전송 · 입력 토큰 " + inputTokens + ")");
        }
        System.out.println("대화를 마칩니다.");
    }

    static JsonObject ask(JsonArray messages) throws Exception {
        String apiKey = System.getenv("API_KEY");
        String baseUrl = System.getenv("BASE_URL") != null ? System.getenv("BASE_URL") : "https://openrouter.ai/api/v1";
        String model = System.getenv("MODEL") != null ? System.getenv("MODEL") : "google/gemma-4-26b-a4b-it";

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", 0.3);
        body.addProperty("max_tokens", 300);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode() + " : " + response.body());
        }
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    static JsonObject message(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    /** 키보드 한 줄 읽기 — 터미널(콘솔)이면 Console로 읽어 한글이 깨지지 않게 함 */
    static BufferedReader stdin;
    static String readLine() throws Exception {
        Console console = System.console();
        if (console != null) return console.readLine();
        if (stdin == null) stdin = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line = stdin.readLine();
        if (line != null) System.out.println(line);                 // 파이프 입력일 때 질문을 화면에 보여 줌
        return line;
    }
}
