import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * [1교시 · 준비] 실습 환경 점검
 * - Java 버전, 환경변수, Gson 라이브러리, API 접속을 순서대로 확인함
 * - Gson 없이도 동작하도록 JSON을 문자열로 직접 작성함
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar ch0_setup/Step00Check.java
 */
public class Step00Check {

    public static void main(String[] args) throws Exception {
        System.out.println("== 1. Java 버전 ==");
        System.out.println("java.version = " + System.getProperty("java.version") + "  (11 이상이면 OK)");

        System.out.println("\n== 2. 환경변수 ==");
        String apiKey = System.getenv("API_KEY");
        String baseUrl = env("BASE_URL", "https://openrouter.ai/api/v1");
        String model = env("MODEL", "google/gemma-4-26b-a4b-it");
        System.out.println("API_KEY  = " + mask(apiKey));
        System.out.println("BASE_URL = " + baseUrl);
        System.out.println("MODEL    = " + model);
        if (apiKey == null || apiKey.trim().isEmpty()) {
            System.out.println("→ API_KEY가 없음. 배포받은 키를 환경변수로 등록한 뒤 VS Code를 다시 시작할 것");
            return;
        }

        System.out.println("\n== 3. Gson 라이브러리 ==");
        try {
            Class.forName("com.google.gson.Gson");
            System.out.println("Gson OK");
        } catch (ClassNotFoundException e) {
            System.out.println("Gson 없음 → lib/gson-2.10.1.jar가 클래스패스에 있는지 확인 (초급 N01·중급 Step01부터 필요)");
        }

        System.out.println("\n== 4. API 호출 ==");
        String body = "{\"model\":\"" + model + "\","
                + "\"messages\":[{\"role\":\"user\",\"content\":\"OK라고만 답해.\"}],"
                + "\"max_tokens\":10,\"temperature\":0}";
        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(baseUrl + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + apiKey.trim())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();
        long start = System.currentTimeMillis();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        long ms = System.currentTimeMillis() - start;

        System.out.println("HTTP " + response.statusCode() + " (" + ms + "ms)");
        System.out.println(response.body());
        if (response.statusCode() == 200) {
            System.out.println("\n→ 환경 점검 완료. 초급은 novice/ch1_first_call/N01FirstCall, 중급은 intermediate/ch1_first_call/Step01FirstCall로 진행");
        } else {
            System.out.println("\n→ 401: 키 확인 / 400·404: MODEL·BASE_URL 확인 / 402: 크레딧 부족 / 그 외: 강사·조교 호출");
        }
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }

    // 키는 앞 6자리만 보여 줌 — 화면 공유·로그에 키 전체가 남지 않게 함
    static String mask(String key) {
        if (key == null || key.trim().isEmpty()) return "(없음)";
        String k = key.trim();
        return k.length() <= 6 ? "******" : k.substring(0, 6) + "******";
    }
}
