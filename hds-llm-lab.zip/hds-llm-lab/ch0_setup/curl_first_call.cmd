@echo off
rem [Lesson 1 / Lab 1-1] First call with curl (Windows Command Prompt)
rem Run from the lab root folder (C:\hds-llm-lab). Requires the API_KEY environment variable.
rem   ch0_setup\curl_first_call.cmd
rem In PowerShell use curl.exe and $env:API_KEY instead of %API_KEY%.
rem NOTE: keep this file ASCII-only. cmd.exe parses .cmd files in the OEM code page (CP949).

chcp 65001 > nul
if "%BASE_URL%"=="" set BASE_URL=https://openrouter.ai/api/v1

curl.exe -s %BASE_URL%/chat/completions ^
  -H "Authorization: Bearer %API_KEY%" ^
  -H "Content-Type: application/json" ^
  -d @ch0_setup\request.json
echo.
