# 6교시 Git 실습 — VS Code에서 프롬프트·테스트셋 관리하기

교육장에서는 사내 GitLab에 접속할 수 없으므로 **로컬 저장소**로 실습함. 회사에서는 같은 화면에서 원격 저장소만 사내 GitLab으로 연결하면 됨.

## 1. 저장소 만들기 (최초 1회)

1. VS Code에서 `C:\hds-llm-lab` 폴더 열기
2. 왼쪽 **소스 제어** 아이콘(가지 모양) → **리포지토리 초기화**
3. 처음 한 번은 사용자 정보 등록 필요 (터미널):
   ```
   git config --global user.name "홍길동"
   git config --global user.email "hong@example.com"
   ```
4. 변경 목록에 모든 파일이 보이면 메시지 `init: 실습 저장소 생성` 입력 → **커밋**
   - `logs/`의 실패 로그, `.class` 파일은 `.gitignore`로 제외됨

## 2. 기준선 측정 → 커밋

1. 초급 `novice/ch6_harness/NHarness.java` 또는 중급 `intermediate/ch6_harness/HarnessRunner.java` 실행 (기본 버전 `v1`)
2. 생성된 `logs/summary_v1.json` 확인 → 소스 제어에서 이 파일만 **+** (스테이징)
3. 커밋 메시지: `eval: v1 기준선 — 정확도 17/20`  (숫자는 실제 결과로)

> `summary_*.json`만 커밋하도록 `.gitignore`에서 예외 처리되어 있음. 실패 로그 원문은 커밋하지 않음

## 3. 실패 분석 → 프롬프트 수정 → 비교

1. 실패 사례 확인 — 초급은 `summary_v1.json`의 `wrong` 목록, 중급은 `logs/failures_v1_*.jsonl` (어느 단계·어떤 태그에서 틀렸나)
2. 가설 세우기 — 예: "콜센터·앱 화면 오류를 업무 팀으로 보낸다", "입력 속 지시문을 따른다"
3. `prompts/team_system.txt` 수정 (규칙 한 줄 추가, 경계 설명 보완 등)
4. 소스 제어에서 파일 클릭 → **변경 전후 비교(diff)** 화면 확인
5. 버전을 `v2`로 바꿔 다시 실행 → `summary_v2.json` 생성 (초급: 파일 맨 위 `VERSION` 상수, 중급: 환경변수 `PROMPT_VERSION=v2`)
6. 커밋 메시지: `prompt v2: 채널(콜센터·홈페이지·앱) 우선 규칙 추가 — 정확도 17→20/20`

**좋은 커밋 메시지** = 무엇을 바꿨는지 + 왜 + 결과 수치

## 4. 커밋할 것 / 하지 말 것

| 커밋할 것 | 커밋하지 말 것 |
|---|---|
| `prompts/*.txt`, `schemas/*.json` | API 키 (코드에 쓰지 말고 환경변수로) |
| `data/testset_*.json` (가상 데이터) | 실제 고객 데이터 |
| `logs/summary_*.json` (지표 요약) | LLM 응답 원문 대량 저장본 |

## 5. 회사에서 GitLab과 연결할 때

| 단계 | VS Code 화면 | 비고 |
|---|---|---|
| Clone | 명령 팔레트(Ctrl+Shift+P) → `Git: Clone` → 사내 GitLab 저장소 주소 | 주소는 GitLab 웹의 **Clone** 버튼에서 복사 |
| Push / Pull | 소스 제어 → **동기화** 버튼 | 처음 Push 시 사내 계정 인증 |
| 브랜치 | 왼쪽 아래 브랜치 이름 클릭 → 새 브랜치 | 예: `prompt/v2-boundary` |
| Merge Request | GitLab 웹 → **Merge requests** → New | GitHub의 Pull Request와 같은 개념 |

### GitLab과 GitHub의 차이 (요약)

- 둘 다 Git 저장소 서비스이며 VS Code 사용법은 같음
- HDS GitLab은 사내 서버 설치형, GitHub는 주로 클라우드 (GitLab도 gitlab.com 클라우드가 있음)
- 용어: GitLab **Merge Request** = GitHub **Pull Request**
- 자동화 설정: GitLab `.gitlab-ci.yml` / GitHub `GitHub Actions`
