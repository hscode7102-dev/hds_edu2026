# 생성형 AI 활용 서비스 개발 과정 — 실습 코드

현대HDS SM본부 대상 1일 과정(2026-10-23)의 Java 실습 코드.

- 기준: **Java 11 문법**(강의장 JDK 17), **VS Code**, JSON 라이브러리는 **Gson 하나**
- 호출 대상: 교육장은 **OpenRouter**, 회사에서는 환경변수만 바꿔 **사내 Gemma4 서버**
- 데이터: 고객·계약·청구·약관은 모두 **실습용 가상 데이터**

## 레벨 선택 — 초급(novice) / 중급(intermediate)

같은 교시, 같은 데이터·프롬프트로 두 가지 난이도를 제공함. 본인 레벨 폴더의 파일만 따라가면 됨.

| | 초급 `novice/` | 중급 `intermediate/` |
|---|---|---|
| 대상 | Java는 익숙하나 HTTP·JSON 라이브러리 경험이 적은 분 | 실무에 바로 옮길 구조가 궁금한 분 |
| 코드 모양 | 위에서 아래로 읽히는 `main` 한 덩어리, 줄마다 설명 주석 | 역할별 메서드 분리, 예외·로그·재시도 구조 |
| 파일 이름 | `N`으로 시작 (`N01FirstCall.java`) | `Step`·`Lab`으로 시작 (`Step01FirstCall.java`) |
| 빈칸(TODO) | 종합실습마다 **1곳** + ✏️ 바꿔 보기 | 종합실습마다 **3곳** + 도전 과제(`intermediate/CHALLENGES.md`) |
| 검증 | 허용값·범위 검사, 실패 시 REVIEW | 3단계 검증 + 1회 복구 요청 + 업무 정책 |
| 추가 | — | 스트리밍(Step04), Tool Calling 에이전트(Step07) |

- 진도가 밀리면 초급 → 중급으로 바꿔도 결과 화면이 같은 흐름이라 따라오기 쉬움
- 중급 수강생도 초급 파일을 먼저 읽으면 "최소한으로 필요한 코드"가 무엇인지 보임

## 폴더 구성

| 폴더 | 교시 | 초급 `novice/…` | 중급 `intermediate/…` | 내용 |
|---|---|---|---|---|
| `ch0_setup` (공통) | 1교시 | `Step00Check.java`, `curl_first_call.cmd`, `request.json` | ← 공통 | 환경 점검, curl 첫 호출 |
| `ch1_first_call` | 1교시 | `N01FirstCall` | `Step01FirstCall` | 첫 호출 — 요청 JSON, 응답에서 content·usage 꺼내기 |
| `ch2_request_response` | 2교시 | `N02Params`, `N03Retry`, `N04Chatbot` | `Step02Params`, `Step03RetryLog`, `Step04Streaming`, `Step04Chatbot` | 파라미터 실험, 재시도·로그, (중급) 스트리밍 · **선택(참고용)** 콘솔 챗봇 `N04Chatbot`·`Step04Chatbot` — 수업 중 미진행 |
| `ch3_prompting` | 3교시 | `N05Prompting` | `Step05Prompting` | 작업의뢰 → 담당 팀 분류, Zero-shot vs Few-shot |
| `ch4_structured` | 4교시 | `N06Structured` | `Step06Structured` | 시스템 프롬프트 + json_schema + 검증 |
| `ch5_lab_coverage` | 5교시 | `NLabACoverageStart` / `Solution` | `LabACoverageStart` / `Solution` | 종합실습 Ⅰ: 설계사 포탈 고객 보장 분석 |
| `ch6_harness` | 6교시 | `NHarness` | `HarnessRunner` | 테스트셋 채점·성적표, (중급) 3단계 검증·실패 로그 |
| `ch7_lab_claims` | 7교시 | `NLabBClaimsStart` / `Solution` | `LabBClaimsStart` / `Solution` | 종합실습 Ⅱ: 보상 포탈 실손 청구 심사 보조 |
| `ch7_agent` | 7교시(선택) | — | `Step07ToolAgent` | Tool Calling 최소 에이전트 루프 + 가드레일 |
| `appendix_java8` | 부록 | `Java8FirstCall.java` | | Java 8 환경용 `HttpURLConnection` 버전 |
| `appendix_spring` | 부록 | `README.md` | | Spring Boot 연동 참고 코드 |
| `prompts/`, `schemas/`, `data/` | 공통 | | | 프롬프트·JSON Schema·가상 데이터 (두 레벨이 같이 사용) |
| `lib/` | 공통 | `gson-2.10.1.jar` | | JSON 라이브러리 (사내 반입 시 이 jar 하나만 필요) |
| `git_practice.md` | 6교시 | | | VS Code Git 실습 순서 |

## 1. 준비

1. JDK 17, VS Code + **Extension Pack for Java**, Git 설치 (강의장 노트북은 사전 설치됨)
2. VS Code에서 **폴더 열기**로 `C:\hds-llm-lab`을 엶 → `.vscode/settings.json`이 두 레벨의 소스 폴더와 `lib/` jar를 자동 인식

## 2. API 키 등록 (교육 당일)

배포받은 키를 환경변수로 등록. **코드에 직접 쓰지 않음.**

```
setx API_KEY "sk-or-배포받은키"
```

- 등록 후 **VS Code를 완전히 종료했다가 다시 열어야** 적용됨
- 선택 환경변수: `BASE_URL`(기본 `https://openrouter.ai/api/v1`), `MODEL`(기본 `google/gemma-4-26b-a4b-it`)

## 3. 실행

**VS Code**: 파일을 열고 `main` 위의 **Run** 클릭 (또는 F5 → "현재 파일 실행")

**터미널** (`C:\hds-llm-lab`에서):

```
java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar ch0_setup/Step00Check.java
java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar novice/ch1_first_call/N01FirstCall.java
java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch4_structured/Step06Structured.java
java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch5_lab_coverage/LabACoverageSolution.java C002
```

- 모든 파일은 **`C:\hds-llm-lab` 폴더를 기준 경로**로 `prompts/`, `data/`를 읽음 → 다른 폴더에서 실행하면 파일을 못 찾음
- `-Dfile.encoding=UTF-8`: JDK 17에서 한글 소스·출력이 깨지지 않게 함 (JDK 18 이상은 생략 가능)

### 실행 옵션 (환경변수, 중급)

| 변수 | 대상 | 설명 |
|---|---|---|
| `USE_JSON_SCHEMA=false` | Step06, HarnessRunner | json_schema 없이 프롬프트만으로 JSON 받기 (사내 서버 미지원 시 폴백 경로) |
| `PROMPT_FILE`, `PROMPT_VERSION` | HarnessRunner | 측정할 프롬프트 파일과 버전 이름 (초급 `NHarness`는 파일 맨 위 상수를 고침) |
| `SLEEP_MS` | HarnessRunner | 호출 간격(기본 300ms) — 30명 동시 실습 시 호출 몰림 완화 |
| `USE_CLAUSE_LOOKUP=false` | LabBClaims | 약관 조회 없이 LLM만으로 처리 → 인용 검증 실패를 관찰 |

## 4. 회사에서 사내 서버로 전환

```
setx BASE_URL "https://(사내 Gemma4 서버 주소)/v1"
setx MODEL "Gemma4-26b-a4b-it"
setx API_KEY "(사내 키)"
```

- 코드는 그대로 사용. `provider.require_parameters`(OpenRouter 전용 옵션)는 BASE_URL이 OpenRouter일 때만 자동으로 붙음
- **사내 서버의 json_schema·tools(Tool Calling) 지원 여부는 별도 확인 필요.** json_schema 미지원이면 중급 코드의 `USE_JSON_SCHEMA=false` 폴백 경로 사용
- 회사 환경이 Java 8이면 `appendix_java8/Java8FirstCall.java`의 `post()` 방식으로 HTTP 호출 부분만 교체

## 5. 자주 나는 오류

| 증상 | 원인·조치 |
|---|---|
| `API_KEY가 없음`, HTTP 401 | 키 등록 후 VS Code를 다시 시작했는지, 키 오타·만료 확인 |
| HTTP 402 | 크레딧 부족 → 강사에게 알림 |
| HTTP 400 `not a valid model ID` | `MODEL` 오타 (OpenRouter는 잘못된 모델 ID에 400을 돌려줌) |
| HTTP 404 | `BASE_URL` 오타 |
| HTTP 400 (4교시 이후) | 서버·제공사가 json_schema(또는 tools)를 지원하지 않을 수 있음 |
| HTTP 429 | 호출 한도·몰림 → 잠시 후 재실행 (2교시 재시도 방식) |
| `NoSuchFileException: prompts/...` | `C:\hds-llm-lab`이 아닌 곳에서 실행함 |
| `package com.google.gson does not exist` | `-cp lib/gson-2.10.1.jar` 누락, 또는 VS Code에서 상위·하위 폴더를 엶 |

## 검증 상태 (2026-10-16)

- 전체 소스 `javac --release 11` 컴파일 통과(JDK 17.0.20), `appendix_java8`은 `--release 8` 통과
- OpenAI 호환 **모의 서버**로 공통·초급·중급 23개 파일 전부를 실행해 HTTP 요청·응답·파싱·검증·집계·Tool Calling 루프 동작 확인, 에이전트 가드레일 7개 경우 확인
- **실제 OpenRouter 호출(`google/gemma-4-26b-a4b-it`)로 두 레벨 전체 실행 확인**: json_schema·tool calling 지원, Zero-shot 7/10 → Few-shot 10/10, 4교시 10/10, 6교시 v1 17~18/20 → 채널 규칙 v2 20/20
- 사내 Gemma4 서버의 json_schema·tool calling 지원 여부는 별도 확인 필요
