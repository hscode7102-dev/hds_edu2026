# [부록] Spring Boot 연동 예시 (7교시 시연용, 여유 시)

실습 코드의 호출 로직을 Spring Boot 서비스 계층으로 옮긴 참고 코드임. 실습 폴더에서는 컴파일되지 않도록 `.java` 파일로 두지 않고 이 문서에만 수록함.

- 대상: Spring Boot 3.x (Java 17+). Boot 2.x(Java 8/11)도 `RestTemplate` 부분은 동일
- JSON: Spring 기본 Jackson 사용 (실습의 Gson 대신)
- 설정값은 `application.yml` + 환경변수로 주입 (키를 코드·저장소에 넣지 않음)

## application.yml

```yaml
llm:
  base-url: ${BASE_URL:https://openrouter.ai/api/v1}
  model: ${MODEL:google/gemma-4-26b-a4b-it}
  api-key: ${API_KEY}
```

## LlmClient.java

```java
@Component
public class LlmClient {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private final String baseUrl;
    private final String model;
    private final String apiKey;

    public LlmClient(RestTemplateBuilder builder, ObjectMapper objectMapper,
                     @Value("${llm.base-url}") String baseUrl,
                     @Value("${llm.model}") String model,
                     @Value("${llm.api-key}") String apiKey) {
        this.restTemplate = builder
                .setConnectTimeout(Duration.ofSeconds(10))
                .setReadTimeout(Duration.ofSeconds(60))
                .build();
        this.objectMapper = objectMapper;
        this.baseUrl = baseUrl;
        this.model = model;
        this.apiKey = apiKey;
    }

    /** 시스템 프롬프트 + 사용자 입력 → 모델 답변(content) 문자열 */
    public String chat(String systemPrompt, String userText) throws JsonProcessingException {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", model);
        body.put("temperature", 0.0);
        body.put("max_tokens", 300);
        body.put("messages", Arrays.asList(
                Map.of("role", "system", "content", systemPrompt),
                Map.of("role", "user", "content", "<request>\n" + userText + "\n</request>")));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        String response = restTemplate.postForObject(baseUrl + "/chat/completions",
                new HttpEntity<>(body, headers), String.class);
        JsonNode root = objectMapper.readTree(response);
        return root.path("choices").path(0).path("message").path("content").asText();
    }
}
```

## TeamRoutingService.java (4교시 검증 로직 이식)

```java
@Service
public class TeamRoutingService {

    private static final Set<String> ALLOWED = Set.of("장기계약팀", "장기유지팀", "손사지원팀", /* ... */ "REVIEW");

    private final LlmClient llm;
    private final ObjectMapper objectMapper;
    private final String systemPrompt;   // prompts/team_system.txt를 리소스로 로드

    // 생성자 생략

    public RoutingResult route(String requestText) throws JsonProcessingException {
        String raw = llm.chat(systemPrompt, requestText);
        RoutingResult r = objectMapper.readValue(extractJson(raw), RoutingResult.class);
        if (r.team() == null || !ALLOWED.contains(r.team())) {
            return RoutingResult.review("허용되지 않은 team");      // 잘못된 결과를 다음 시스템에 넘기지 않음
        }
        if (r.confidence() < 0.70) {
            return new RoutingResult("REVIEW", r.reason(), r.confidence(), true);
        }
        return r;
    }
}
```

> 실습 코드의 재시도(Step03)·구조화 출력(Step06) 로직은 이 서비스 계층에 그대로 옮기면 됨. 운영에서는 Spring Retry, Resilience4j 같은 라이브러리로 대체 가능
