# 중급 도전 과제

교시 실습을 일찍 끝낸 경우 이어서 진행. 정답 코드는 제공하지 않음. 강사·조교와 함께 리뷰함.

| 교시 | 파일 | 도전 과제 |
|---|---|---|
| 1 | `Step01FirstCall` | 요청·응답 DTO 클래스(`ChatRequest`, `ChatResponse`)를 만들어 `JsonObject` 조립을 Gson 직렬화로 바꾸기 |
| 2 | `Step03RetryLog` | 연속 실패 5회면 30초간 호출을 막는 간단한 서킷 브레이커 추가. 로그에 누적 토큰·추정 비용(입력 $0.042/M, 출력 $0.22/M 가정) 출력 |
| 2 | `Step04Chatbot` | 오래된 대화를 잘라 버리는 대신 LLM으로 '지금까지 대화 요약' 한 문단을 만들어 system 다음에 넣기 — 토큰과 기억의 균형 비교 |
| 2 | `Step04Streaming` | 스트리밍 중 `max_tokens` 도달(`finish_reason=length`)을 감지해 "답변이 잘렸음" 표시 |
| 3 | `Step05Prompting` | Few-shot 예시를 `data/testset_team_routing.json`에서 자동으로 고르는 방식(같은 보종 우선)으로 바꾸고 정확도 비교 |
| 4 | `Step06Structured` | `confidence` 대신 근거 문장(`evidence`) 필드를 스키마에 추가하고, 근거가 입력 원문에 실제로 있는지 Java로 검사 |
| 5 | `LabACoverageSolution` | 특약명 → 분류 매핑 결과를 파일 캐시(`logs/mapping_cache.json`)에 저장해 같은 특약명은 LLM을 다시 부르지 않기 (토큰·시간 절약) |
| 6 | `HarnessRunner` | 같은 테스트셋을 3회 반복 실행해 문항별 일관성(3회 모두 같은 답인 비율) 지표 추가 |
| 7 | `LabBClaimsSolution` | 청구 3건을 병렬(`CompletableFuture`, 동시 2건 제한)로 처리하고 순서대로 출력 |
| 7 | `Step07ToolAgent` | 도구 `count_claims(contract_no)` 추가, 같은 도구·같은 인자를 반복 호출하면 루프를 멈추는 가드레일 추가 |

## 검토 기준

- 업무 규칙·계산은 Java, 해석만 LLM이 맡는 구조를 유지했는가
- 실패했을 때 잘못된 결과를 넘기지 않고 REVIEW·오류로 명시하는가
- 로그에 API 키·고객 원문을 남기지 않는가
