import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.annotations.SerializedName;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * [4교시 · 실습 4] 시스템 프롬프트 + Structured Output + 3단계 검증 + 1회 복구
 *
 * 흐름: 시스템 프롬프트(규칙) + 사용자 메시지(데이터) → json_schema로 형식 강제 → 파싱
 *       → 1·2단계 검증(필수값·허용값·범위) → 실패 시 오류를 알려 주고 1회만 재요청
 *       → 3단계 업무 정책(신뢰도 낮으면 REVIEW) → 결과
 *
 * 환경변수 USE_JSON_SCHEMA=false 로 실행하면 json_schema 없이 프롬프트만으로 JSON을 받는 폴백 경로를 실행함
 * (사내 서버가 json_schema를 지원하지 않을 때의 대응 방식)
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch4_structured/Step06Structured.java
 *       (인자로 의뢰 문장을 주면 그 한 건만 분류)
 */
public class Step06Structured {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final boolean USE_JSON_SCHEMA = !"false".equalsIgnoreCase(env("USE_JSON_SCHEMA", "true"));
    static final double REVIEW_THRESHOLD = 0.70;
    static final Gson GSON = new Gson();
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    static final List<String> ALLOWED_TEAMS = Arrays.asList(
            "장기계약팀", "장기유지팀", "손사지원팀", "자동차보험팀", "자동차보상팀", "일반보험팀",
            "마케팅팀", "정보계지원팀", "콜센터팀", "홈페이지모바일팀", "개발지원팀", "REVIEW");

    /** 모델 출력이 담길 Java 객체 — 필드 이름은 스키마와 같게 */
    static class Result {
        String team;
        String reason;
        Double confidence;
        @SerializedName("needs_review") Boolean needsReview;
    }

    public static void main(String[] args) throws Exception {
        String systemPrompt = read("prompts/team_system.txt");
        JsonObject schema = JsonParser.parseString(read("schemas/team_routing.schema.json")).getAsJsonObject();
        System.out.println("모드: " + (USE_JSON_SCHEMA ? "json_schema (서버가 형식 강제)" : "폴백 (프롬프트 + 애플리케이션 검증)"));

        if (args.length > 0) {
            Result r = classify(systemPrompt, schema, args[0]);
            System.out.println(GSON.toJson(r));
            return;
        }
        JsonArray requests = JsonParser.parseString(read("data/requests.json")).getAsJsonArray();
        int correct = 0;
        for (JsonElement e : requests) {
            JsonObject req = e.getAsJsonObject();
            Result r = classify(systemPrompt, schema, req.get("text").getAsString());
            boolean ok = req.get("expected").getAsString().equals(r.team);
            if (ok) correct++;
            System.out.printf("%s %s → %-8s conf=%.2f review=%s | %s%n", ok ? "O" : "X",
                    req.get("id").getAsString(), r.team, r.confidence, r.needsReview, r.reason);
        }
        System.out.println("→ 정확도 " + correct + "/" + requests.size());
    }

    static Result classify(String systemPrompt, JsonObject schema, String requestText) throws Exception {
        JsonArray messages = new JsonArray();
        messages.add(message("system", systemPrompt));
        // 입력은 구분자로 감싸 '명령'이 아닌 '데이터'임을 분명히 함
        messages.add(message("user", "<request>\n" + requestText + "\n</request>"));

        String raw = content(chat(messages, schema));
        Result r = parse(raw);
        List<String> errors = validate(r);

        if (!errors.isEmpty()) {
            // 복구: 실패한 응답과 구체적인 오류를 알려 주고 1회만 재요청
            System.out.println("  [검증 실패 → 1회 복구] " + errors);
            messages.add(message("assistant", raw));
            messages.add(message("user", "위 출력에 다음 오류가 있다: " + String.join(", ", errors)
                    + ". 같은 형식의 JSON 한 개만 다시 출력하라."));
            raw = content(chat(messages, schema));
            r = parse(raw);
            errors = validate(r);
            if (!errors.isEmpty()) {
                // 그래도 실패하면 잘못된 결과를 넘기지 않고 명시적으로 REVIEW 처리
                Result fail = new Result();
                fail.team = "REVIEW";
                fail.reason = "검증 실패: " + String.join(", ", errors);
                fail.confidence = 0.0;
                fail.needsReview = true;
                return fail;
            }
        }
        return applyPolicy(r, requestText);
    }

    /** 1·2단계 검증: 파싱·필수값·허용값·길이·범위 */
    static List<String> validate(Result r) {
        List<String> errors = new ArrayList<>();
        if (r == null) { errors.add("JSON 파싱 불가"); return errors; }
        if (r.team == null) errors.add("team 누락");
        else if (!ALLOWED_TEAMS.contains(r.team)) errors.add("허용되지 않은 team: " + r.team);
        if (r.reason == null || r.reason.trim().isEmpty()) errors.add("reason 누락");
        else if (r.reason.length() > 40) errors.add("reason 40자 초과");
        if (r.confidence == null) errors.add("confidence 누락");
        else if (r.confidence < 0.0 || r.confidence > 1.0) errors.add("confidence 범위(0~1) 위반");
        if (r.needsReview == null) errors.add("needs_review 누락");
        return errors;
    }

    /** 3단계: 업무 정책은 모델이 아니라 Java가 강제 */
    static Result applyPolicy(Result r, String requestText) {
        if (r.confidence < REVIEW_THRESHOLD) {
            r.team = "REVIEW";
            r.needsReview = true;
        }
        // 업무 의미 검증 예시: 'DW'·'통계'가 있는데 정보계지원팀이 아니면 사람 검토
        boolean analytics = requestText.contains("DW") || requestText.contains("통계");
        if (analytics && !"정보계지원팀".equals(r.team)) r.needsReview = true;
        if ("REVIEW".equals(r.team)) r.needsReview = true;
        return r;
    }

    /** 코드펜스·앞뒤 설명문이 섞여도 첫 '{'부터 마지막 '}'까지를 파싱 (폴백 경로 대비) */
    static Result parse(String raw) {
        if (raw == null) return null;
        String s = raw.replace("```json", "").replace("```", "").trim();
        int l = s.indexOf('{'), rr = s.lastIndexOf('}');
        if (l < 0 || rr <= l) return null;
        try {
            return GSON.fromJson(s.substring(l, rr + 1), Result.class);
        } catch (Exception e) {
            return null;
        }
    }

    static JsonObject chat(JsonArray messages, JsonObject schema) throws IOException, InterruptedException {
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);
        body.addProperty("max_tokens", 300);

        if (USE_JSON_SCHEMA) {
            JsonObject jsonSchema = new JsonObject();
            jsonSchema.addProperty("name", "team_routing");
            jsonSchema.addProperty("strict", true);
            jsonSchema.add("schema", schema);
            JsonObject responseFormat = new JsonObject();
            responseFormat.addProperty("type", "json_schema");
            responseFormat.add("json_schema", jsonSchema);
            body.add("response_format", responseFormat);

            // OpenRouter 전용: 스키마를 지원하는 제공사로만 보냄 (조용히 무시되는 것 방지)
            // 사내 서버에는 이 필드를 보내지 않음
            if (BASE_URL.contains("openrouter.ai")) {
                JsonObject provider = new JsonObject();
                provider.addProperty("require_parameters", true);
                body.add("provider", provider);
            }
        }

        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            // 400이면 서버가 json_schema를 지원하지 않을 수 있음 → USE_JSON_SCHEMA=false로 폴백 경로 확인
            throw new IOException("HTTP " + response.statusCode() + ": " + response.body());
        }
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    static JsonObject message(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    static String content(JsonObject res) {
        JsonObject msg = res.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
        return msg.get("content").isJsonNull() ? "" : msg.get("content").getAsString();
    }

    static String read(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
