import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * [2교시 · 실습 2] timeout · retry · 로그 — 안정적인 호출기
 * - 재시도할 오류(timeout, 408, 429, 5xx)와 즉시 멈출 오류(400, 401, 403, 404)를 구분
 * - 지수 백오프 + jitter: 최대 3회 시도, 시도 사이 대기 500ms → 1s (시도를 늘리면 2s, 4s …)
 * - 로그는 한 줄 JSON. 키·질문 원문·답변 원문은 남기지 않음
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch2_request_response/Step03RetryLog.java
 *       (인자로 bad-model을 주면 즉시 실패 흐름을 관찰 — OpenRouter는 400 'not a valid model ID')
 */
public class Step03RetryLog {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final int MAX_ATTEMPTS = 3;
    static final Duration TIMEOUT = Duration.ofSeconds(30);
    static final Gson GSON = new Gson();
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    /** 재시도하면 성공할 수도 있는 오류 */
    static class RetryableException extends Exception {
        final long retryAfterMs;
        RetryableException(String msg, long retryAfterMs) { super(msg); this.retryAfterMs = retryAfterMs; }
    }

    /** 재시도해도 소용없는 오류 — 요청이나 설정을 고쳐야 함 */
    static class FatalException extends Exception {
        FatalException(String msg) { super(msg); }
    }

    public static void main(String[] args) throws Exception {
        String model = (args.length > 0 && args[0].equals("bad-model")) ? "no-such/model" : MODEL;
        try {
            JsonObject res = callWithRetry(model, "실손보험을 한 문장으로 설명해줘.");
            String content = res.getAsJsonArray("choices").get(0).getAsJsonObject()
                    .getAsJsonObject("message").get("content").getAsString();
            System.out.println("\n답변: " + content);
        } catch (FatalException e) {
            System.out.println("\n즉시 실패(재시도 안 함): " + e.getMessage());
        } catch (RetryableException e) {
            System.out.println("\n재시도 " + MAX_ATTEMPTS + "회 모두 실패: " + e.getMessage());
        }
    }

    static JsonObject callWithRetry(String model, String userText) throws Exception {
        String requestId = UUID.randomUUID().toString().substring(0, 8);
        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            long start = System.currentTimeMillis();
            try {
                JsonObject res = callOnce(model, userText);
                log(requestId, model, attempt, 200, System.currentTimeMillis() - start, res, null);
                return res;
            } catch (RetryableException e) {
                log(requestId, model, attempt, -1, System.currentTimeMillis() - start, null, e.getMessage());
                if (attempt == MAX_ATTEMPTS) throw e;
                long base = 500L * (1L << (attempt - 1));                     // 500ms, 1s, 2s … (2^(n-1)배)
                long jitter = ThreadLocalRandom.current().nextLong(250L);     // 동시 재시도 몰림 방지
                long wait = Math.max(base + jitter, e.retryAfterMs);          // 서버가 Retry-After를 주면 우선
                Thread.sleep(wait);
            } catch (FatalException e) {
                log(requestId, model, attempt, -1, System.currentTimeMillis() - start, null, e.getMessage());
                throw e;
            }
        }
        throw new IllegalStateException("도달하지 않는 코드");
    }

    static JsonObject callOnce(String model, String userText) throws RetryableException, FatalException, InterruptedException {
        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        JsonArray messages = new JsonArray();
        JsonObject m = new JsonObject();
        m.addProperty("role", "user");
        m.addProperty("content", userText);
        messages.add(m);
        body.add("messages", messages);
        body.addProperty("temperature", 0.2);
        body.addProperty("max_tokens", 200);

        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(TIMEOUT)
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();

        HttpResponse<String> response;
        try {
            response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (IOException e) {
            // HttpTimeoutException, 연결 끊김 등 일시적 네트워크 오류
            throw new RetryableException("네트워크/timeout: " + e.getClass().getSimpleName(), 0);
        }

        int status = response.statusCode();
        if (status == 200) return JsonParser.parseString(response.body()).getAsJsonObject();
        if (status == 408 || status == 429 || status >= 500) {
            long retryAfterMs = response.headers().firstValue("Retry-After")
                    .map(Step03RetryLog::parseRetryAfter).orElse(0L);
            throw new RetryableException("HTTP " + status, retryAfterMs);
        }
        // 400 요청 형식 / 401·403 키·권한 / 402 크레딧 / 404 주소·모델명 → 고쳐야 할 문제
        throw new FatalException("HTTP " + status + " " + shortError(response.body()));
    }

    /** 한 줄 JSON 로그. 키·질문·답변 원문은 남기지 않음 */
    static void log(String requestId, String model, int attempt, int status, long latencyMs, JsonObject res, String error) {
        JsonObject line = new JsonObject();
        line.addProperty("request_id", requestId);
        line.addProperty("model", model);
        line.addProperty("attempt", attempt);
        line.addProperty("status", status);
        line.addProperty("latency_ms", latencyMs);
        if (res != null) {
            JsonObject choice = res.getAsJsonArray("choices").get(0).getAsJsonObject();
            if (choice.has("finish_reason") && !choice.get("finish_reason").isJsonNull()) {
                line.addProperty("finish_reason", choice.get("finish_reason").getAsString());
            }
            if (res.has("usage")) {
                JsonObject u = res.getAsJsonObject("usage");
                line.addProperty("prompt_tokens", u.get("prompt_tokens").getAsInt());
                line.addProperty("completion_tokens", u.get("completion_tokens").getAsInt());
            }
        }
        if (error != null) line.addProperty("error", error);
        System.out.println("[LOG] " + GSON.toJson(line));
    }

    static long parseRetryAfter(String v) {
        try { return Long.parseLong(v.trim()) * 1000L; } catch (NumberFormatException e) { return 0L; }
    }

    // 오류 응답의 message만 짧게 — 응답 전문을 로그에 남기지 않음
    static String shortError(String body) {
        try {
            JsonObject err = JsonParser.parseString(body).getAsJsonObject().getAsJsonObject("error");
            return err.get("message").getAsString();
        } catch (Exception e) {
            return body.length() > 120 ? body.substring(0, 120) + "…" : body;
        }
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
