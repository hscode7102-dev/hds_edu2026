import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * [2교시 · 실습 2] 파라미터 실험
 * 실험 1) temperature를 바꿔 같은 질문을 3번씩 → 답이 얼마나 흔들리는지 관찰
 * 실험 2) max_tokens를 작게 → finish_reason = "length"(잘림) 확인
 * 실험 3) 장황한 요청 vs 출력 계약(필드·길이 제한) 요청 → usage(토큰) 비교
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch2_request_response/Step02Params.java
 */
public class Step02Params {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final Gson GSON = new Gson();
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    public static void main(String[] args) throws Exception {
        // 답이 여러 개 나올 수 있는 질문이어야 temperature 차이가 보임 (정답이 하나인 질문은 1.2에서도 같은 답이 나옴)
        String question = "실손보험 광고 문구를 15자 이내로 하나만 지어줘. 문구만 답해.";

        System.out.println("== 실험 1: temperature ==");
        double[] temps = {0.0, 0.7, 1.2};
        for (double t : temps) {
            System.out.print("temperature " + t + " → ");
            for (int i = 0; i < 3; i++) {
                JsonObject res = chat(question, t, 40);
                System.out.print("[" + content(res).trim() + "] ");
            }
            System.out.println();
        }

        System.out.println("\n== 실험 2: max_tokens가 너무 작으면 ==");
        JsonObject cut = chat("실손보험 청구 절차를 단계별로 자세히 설명해줘.", 0.0, 15);
        System.out.println("답변: " + content(cut));
        System.out.println("finish_reason: " + finishReason(cut) + "   ← length면 출력이 잘린 것");

        System.out.println("\n== 실험 3: 응답 최소화 (출력 계약) ==");
        String verbose = "다음 의뢰가 어느 팀 업무인지 자세히 분석해 주세요: 자동차 대물 보상 지급 화면 계산 오류";
        String contract = "다음 의뢰의 담당 팀명만 답하라. 다른 말은 쓰지 마라.\n"
                + "허용 팀: 자동차보험팀, 자동차보상팀, 일반보험팀\n"
                + "의뢰: 자동차 대물 보상 지급 화면 계산 오류";
        JsonObject a = chat(verbose, 0.0, 500);
        JsonObject b = chat(contract, 0.0, 500);
        System.out.println("장황한 요청  → 출력 토큰 " + completionTokens(a) + " / 답변 앞부분: " + head(content(a), 60));
        System.out.println("출력 계약    → 출력 토큰 " + completionTokens(b) + " / 답변: " + content(b).trim());
    }

    static JsonObject chat(String userText, double temperature, int maxTokens) throws IOException, InterruptedException {
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        JsonArray messages = new JsonArray();
        JsonObject m = new JsonObject();
        m.addProperty("role", "user");
        m.addProperty("content", userText);
        messages.add(m);
        body.add("messages", messages);
        body.addProperty("temperature", temperature);
        body.addProperty("max_tokens", maxTokens);

        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            throw new IOException("HTTP " + response.statusCode() + ": " + response.body());
        }
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    static String content(JsonObject res) {
        JsonObject msg = res.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
        return msg.get("content").isJsonNull() ? "" : msg.get("content").getAsString();
    }

    static String finishReason(JsonObject res) {
        JsonObject choice = res.getAsJsonArray("choices").get(0).getAsJsonObject();
        return choice.get("finish_reason").isJsonNull() ? "(없음)" : choice.get("finish_reason").getAsString();
    }

    static int completionTokens(JsonObject res) {
        return res.has("usage") ? res.getAsJsonObject("usage").get("completion_tokens").getAsInt() : -1;
    }

    static String head(String s, int n) {
        String one = s.replace("\n", " ");
        return one.length() <= n ? one : one.substring(0, n) + "…";
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
