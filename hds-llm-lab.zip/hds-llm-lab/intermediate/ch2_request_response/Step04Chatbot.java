import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Iterator;
import java.util.stream.Stream;

/**
 * [중급 · 2교시 · 선택 실습(참고용)] 콘솔 챗봇 — 대화 이력 관리 + 스트리밍 + 이력 길이 제한
 *   ※ 수업 중에는 진행하지 않음. 복습·여유 시간에 실행해 보는 참고 코드
 *
 * 구조
 *   history  : system 메시지 + 최근 대화만 보관 (LLM은 무상태 → 매 요청에 이력 전체를 보냄)
 *   trim()   : 오래된 대화를 잘라 입력 토큰(비용·지연)이 끝없이 늘지 않게 함 — MAX_TURNS 턴만 유지
 *   stream() : 답변을 토큰 단위로 바로 출력 (Step04Streaming과 같은 SSE 처리), 끝까지 받은 뒤 이력에 추가
 *
 * 명령: exit 종료 · /reset 이력 초기화 · /history 지금 보내는 이력 보기
 * 환경변수: MAX_TURNS (기본 4 — 사용자·AI 한 쌍이 1턴)
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch2_request_response/Step04Chatbot.java
 */
public class Step04Chatbot {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final int MAX_TURNS = Integer.parseInt(env("MAX_TURNS", "4"));
    static final String SYSTEM_PROMPT = "너는 현대HDS 개발자를 돕는 보험 업무 용어 도우미다. 3문장 이내로 답하고, 모르면 모른다고 한다.";
    static final Gson GSON = new Gson();
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    public static void main(String[] args) throws Exception {
        JsonArray history = new JsonArray();
        history.add(message("system", SYSTEM_PROMPT));
        System.out.println("보험 용어 도우미 (최근 " + MAX_TURNS + "턴 기억) — exit 종료 · /reset 초기화 · /history 이력 보기");

        while (true) {
            System.out.print("\n나> ");
            String q = readLine();
            if (q == null || q.trim().equalsIgnoreCase("exit")) break;
            q = q.trim();
            if (q.isEmpty()) continue;
            if (q.equals("/reset")) { while (history.size() > 1) history.remove(1); System.out.println("(이력 초기화)"); continue; }
            if (q.equals("/history")) { printHistory(history); continue; }

            history.add(message("user", q));
            int dropped = trim(history);
            System.out.print("AI> ");
            Reply r = stream(history);
            System.out.println();
            if (r.error != null) {                                  // 실패한 질문은 이력에서 빼서 다음 요청이 꼬이지 않게
                history.remove(history.size() - 1);
                System.out.println("[오류] " + r.error);
                continue;
            }
            history.add(message("assistant", r.text.toString()));
            System.out.printf("    (메시지 %d개 전송%s · 입력 토큰 %s · 첫 토큰 %dms)%n", history.size() - 1,   // 방금 추가한 AI 답변 제외
                    dropped > 0 ? ", 오래된 " + dropped + "개 제외" : "",
                    r.promptTokens < 0 ? "?" : String.valueOf(r.promptTokens), r.firstTokenMs);
        }
        System.out.println("대화를 마칩니다.");
    }

    /** system(0번)은 남기고, 최근 MAX_TURNS 턴(사용자·AI 2개씩) + 이번 질문만 유지. 제외한 메시지 수 반환 */
    static int trim(JsonArray history) {
        int keep = 1 + MAX_TURNS * 2 + 1;
        int dropped = 0;
        while (history.size() > keep) { history.remove(1); dropped++; }
        return dropped;
    }

    static class Reply { StringBuilder text = new StringBuilder(); int promptTokens = -1; long firstTokenMs = -1; String error; }

    /** SSE 스트리밍 호출: delta.content를 바로 출력하며 누적, 마지막 청크의 usage가 있으면 기록 */
    static Reply stream(JsonArray history) throws IOException, InterruptedException {
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        body.add("messages", history);
        body.addProperty("temperature", 0.3);
        body.addProperty("max_tokens", 400);
        body.addProperty("stream", true);
        JsonObject opts = new JsonObject();
        opts.addProperty("include_usage", true);                   // 스트리밍에서도 마지막에 토큰 사용량 받기
        body.add("stream_options", opts);

        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(120))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();
        Reply r = new Reply();
        long start = System.currentTimeMillis();
        HttpResponse<Stream<String>> response = HTTP.send(request, HttpResponse.BodyHandlers.ofLines());
        if (response.statusCode() != 200) {
            StringBuilder sb = new StringBuilder();
            response.body().forEach(sb::append);
            r.error = "HTTP " + response.statusCode() + " " + sb;
            return r;
        }
        Iterator<String> lines = response.body().iterator();
        while (lines.hasNext()) {
            String line = lines.next();
            if (line.isEmpty() || line.startsWith(":") || !line.startsWith("data: ")) continue;
            String data = line.substring(6).trim();
            if (data.equals("[DONE]")) break;
            JsonObject chunk = JsonParser.parseString(data).getAsJsonObject();
            if (chunk.has("error")) { r.error = chunk.get("error").toString(); break; }
            if (chunk.has("usage") && chunk.get("usage").isJsonObject()) {
                r.promptTokens = chunk.getAsJsonObject("usage").get("prompt_tokens").getAsInt();
            }
            JsonArray choices = chunk.getAsJsonArray("choices");
            if (choices == null || choices.size() == 0) continue;
            JsonObject delta = choices.get(0).getAsJsonObject().getAsJsonObject("delta");
            JsonElement piece = delta == null ? null : delta.get("content");
            if (piece != null && !piece.isJsonNull()) {
                if (r.firstTokenMs < 0) r.firstTokenMs = System.currentTimeMillis() - start;
                System.out.print(piece.getAsString());
                System.out.flush();
                r.text.append(piece.getAsString());
            }
        }
        if (r.error == null && r.text.length() == 0) r.error = "빈 응답";
        return r;
    }

    static void printHistory(JsonArray history) {
        for (JsonElement e : history) {
            JsonObject m = e.getAsJsonObject();
            String c = m.get("content").getAsString().replace("\n", " ");
            System.out.println("  [" + m.get("role").getAsString() + "] " + (c.length() > 60 ? c.substring(0, 60) + "…" : c));
        }
    }

    static JsonObject message(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    /** 터미널이면 Console로(콘솔 문자집합 그대로 → 한글 안전), 파이프 입력이면 UTF-8로 읽음 */
    static BufferedReader stdin;
    static String readLine() throws IOException {
        Console console = System.console();
        if (console != null) return console.readLine();
        if (stdin == null) stdin = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line = stdin.readLine();
        if (line != null) System.out.println(line);
        return line;
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
