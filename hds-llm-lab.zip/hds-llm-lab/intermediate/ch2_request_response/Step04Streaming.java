import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Iterator;
import java.util.stream.Stream;

/**
 * [2교시 · 강사 시연 / 선택 실습] 스트리밍(SSE)
 * - "stream": true로 요청하면 답변이 "data: {...}" 조각으로 나뉘어 도착함
 * - 조각의 delta.content를 이어 붙여 화면에 바로 출력, "data: [DONE]"이면 종료
 * - ':'로 시작하는 줄은 주석(연결 유지용)이므로 건너뜀
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch2_request_response/Step04Streaming.java
 */
public class Step04Streaming {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");

    public static void main(String[] args) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        JsonArray messages = new JsonArray();
        JsonObject m = new JsonObject();
        m.addProperty("role", "user");
        m.addProperty("content", "실손보험 청구 절차를 5단계로 설명해줘.");
        messages.add(m);
        body.add("messages", messages);
        body.addProperty("temperature", 0.3);
        body.addProperty("max_tokens", 500);
        body.addProperty("stream", true);

        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(120))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(new Gson().toJson(body), StandardCharsets.UTF_8))
                .build();

        // 응답을 한 줄씩 받음 (전체가 끝날 때까지 기다리지 않음)
        HttpResponse<Stream<String>> response = client.send(request, HttpResponse.BodyHandlers.ofLines());
        if (response.statusCode() != 200) {
            System.out.println("HTTP " + response.statusCode());
            response.body().forEach(System.out::println);
            return;
        }

        StringBuilder full = new StringBuilder();
        long start = System.currentTimeMillis();
        long firstTokenMs = -1;
        Iterator<String> lines = response.body().iterator();
        while (lines.hasNext()) {
            String line = lines.next();
            if (line.isEmpty() || line.startsWith(":")) continue;      // 빈 줄·주석 줄
            if (!line.startsWith("data: ")) continue;
            String data = line.substring(6).trim();
            if (data.equals("[DONE]")) break;

            JsonObject chunk = JsonParser.parseString(data).getAsJsonObject();
            if (chunk.has("error")) {                                   // 스트리밍 도중 오류는 이벤트로 옴
                System.out.println("\n[스트리밍 오류] " + chunk.get("error"));
                break;
            }
            JsonArray choices = chunk.getAsJsonArray("choices");
            if (choices == null || choices.size() == 0) continue;
            JsonObject delta = choices.get(0).getAsJsonObject().getAsJsonObject("delta");
            if (delta == null) continue;
            JsonElement piece = delta.get("content");
            if (piece != null && !piece.isJsonNull()) {
                if (firstTokenMs < 0) firstTokenMs = System.currentTimeMillis() - start;
                System.out.print(piece.getAsString());
                System.out.flush();
                full.append(piece.getAsString());
            }
        }
        System.out.println("\n\n첫 토큰까지 " + firstTokenMs + "ms / 전체 " + (System.currentTimeMillis() - start)
                + "ms / 누적 " + full.length() + "자");
        System.out.println("※ JSON 결과가 필요하면 끝까지 모두 받은 뒤 파싱·검증할 것");
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
