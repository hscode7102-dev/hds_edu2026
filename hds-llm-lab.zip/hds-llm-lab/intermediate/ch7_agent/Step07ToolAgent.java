import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

/**
 * [중급 · 7교시 · 심화(선택)] Tool Calling으로 만드는 최소 에이전트 루프
 *
 * 에이전트 = LLM + 도구 + 반복(loop)
 *   1) 질문과 '사용 가능한 도구 목록(tools)'을 함께 보냄
 *   2) 모델이 직접 답하지 않고 tool_calls(어떤 도구를 어떤 인자로)를 돌려주면
 *   3) Java가 도구를 실행하고 결과를 role=tool 메시지로 돌려보냄
 *   4) 모델이 최종 답(content)을 낼 때까지 2~3 반복 — 단, 최대 MAX_STEPS회
 *
 * 가드레일 (실무에서 반드시 Java가 지키는 것)
 *   - 도구는 조회(read-only)만 제공. 지급·변경처럼 되돌릴 수 없는 작업은 도구로 주지 않음 → 사람 승인 흐름으로 분리
 *   - 허용 목록에 없는 도구 이름, 형식이 틀린 인자는 실행하지 않고 오류를 모델에게 돌려줌
 *   - 반복 횟수 상한, 매 단계 로그
 *
 * 주의: 모델·제공사에 따라 tool calling 지원 여부가 다름 (사내 서버는 vLLM 설정에 따라 다름 → 사전 확인 필요)
 *       OpenRouter는 provider.require_parameters=true 로 tools를 지원하는 제공사로만 보냄
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch7_agent/Step07ToolAgent.java ["질문"]
 */
public class Step07ToolAgent {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final int MAX_STEPS = 5;
    static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    static final List<String> ALLOWED_TOOLS = Arrays.asList("get_claim", "get_policy_clauses", "get_customer_contracts");

    /** LLM 호출부를 바꿔 끼울 수 있게 인터페이스로 분리 (테스트에서는 가짜 모델을 넣음) */
    interface ChatFn { JsonObject call(JsonArray messages, JsonArray tools) throws Exception; }
    static ChatFn chatFn = Step07ToolAgent::chat;

    static final String SYSTEM = "역할: 보상 담당자를 돕는 조회 도우미.\n"
            + "- 필요한 정보는 반드시 도구로 조회한다. 조회하지 않은 사실을 지어내지 않는다.\n"
            + "- 지급·부지급을 판단하지 않는다. 담당자가 확인할 점만 정리한다.\n"
            + "- 근거로 쓴 약관 조항 ID를 함께 적는다. 답은 한국어 5줄 이내.";

    public static void main(String[] args) throws Exception {
        String question = args.length > 0 ? args[0]
                : "청구 CL-002를 심사할 때 적용되는 약관 버전과 관련 조항을 찾아서 담당자가 확인할 점을 정리해줘.";
        System.out.println("질문: " + question + "\n");
        System.out.println("\n최종 답변:\n" + run(question));
    }

    static String run(String question) throws Exception {
        JsonArray tools = toolDefinitions();
        JsonArray messages = new JsonArray();
        messages.add(message("system", SYSTEM));
        messages.add(message("user", question));

        for (int step = 1; step <= MAX_STEPS; step++) {
            JsonObject res = chatFn.call(messages, tools);
            JsonObject assistant = res.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
            messages.add(assistant);   // tool_calls가 담긴 assistant 메시지를 그대로 대화에 넣어야 다음 호출이 이어짐

            JsonArray calls = assistant.has("tool_calls") && assistant.get("tool_calls").isJsonArray()
                    ? assistant.getAsJsonArray("tool_calls") : new JsonArray();
            if (calls.size() == 0) {
                return text(assistant);   // 도구 요청이 없으면 최종 답
            }
            for (JsonElement c : calls) {
                JsonObject call = c.getAsJsonObject();
                JsonObject fn = call.getAsJsonObject("function");
                String name = fn.get("name").getAsString();
                String arguments = fn.has("arguments") ? fn.get("arguments").getAsString() : "{}";
                String result = executeTool(name, arguments);
                System.out.println("[step " + step + "] " + name + " " + arguments + " → " + head(result, 80));

                JsonObject toolMsg = new JsonObject();
                toolMsg.addProperty("role", "tool");
                toolMsg.addProperty("tool_call_id", call.get("id").getAsString());
                toolMsg.addProperty("content", result);
                messages.add(toolMsg);
            }
        }
        return "최대 단계(" + MAX_STEPS + ") 초과 — 자동 처리 중단, 담당자에게 넘김";
    }

    // ---------------- 도구 정의 (모델에게 보여 주는 설명서) ----------------

    static JsonArray toolDefinitions() {
        JsonArray tools = new JsonArray();
        tools.add(tool("get_claim", "청구 ID로 청구 건(계약 정보, 청구일, 금액, 서류 요약)을 조회한다.",
                "claim_id", "청구 ID, 예: CL-001"));
        tools.add(tool("get_policy_clauses", "실손 계약의 가입일로 적용되는 약관 버전과 조항 목록을 조회한다.",
                "join_date", "가입일 YYYY-MM-DD"));
        tools.add(tool("get_customer_contracts", "고객 ID로 가입 계약과 특약 목록을 조회한다.",
                "customer_id", "고객 ID, 예: C001"));
        return tools;
    }

    /** 문자열 인자 하나짜리 함수 도구 정의 */
    static JsonObject tool(String name, String description, String param, String paramDesc) {
        JsonObject p = new JsonObject();
        p.addProperty("type", "string");
        p.addProperty("description", paramDesc);
        JsonObject props = new JsonObject();
        props.add(param, p);
        JsonArray required = new JsonArray();
        required.add(param);
        JsonObject parameters = new JsonObject();
        parameters.addProperty("type", "object");
        parameters.add("properties", props);
        parameters.add("required", required);

        JsonObject fn = new JsonObject();
        fn.addProperty("name", name);
        fn.addProperty("description", description);
        fn.add("parameters", parameters);
        JsonObject t = new JsonObject();
        t.addProperty("type", "function");
        t.add("function", fn);
        return t;
    }

    // ---------------- 도구 실행 (가드레일은 여기서) ----------------

    static String executeTool(String name, String argumentsJson) {
        if (!ALLOWED_TOOLS.contains(name)) return error("허용되지 않은 도구: " + name);
        JsonObject args;
        try {
            args = JsonParser.parseString(argumentsJson).getAsJsonObject();
        } catch (Exception e) {
            return error("arguments가 JSON이 아님");
        }
        try {
            switch (name) {
                case "get_claim": {
                    String id = str(args, "claim_id");
                    if (!id.matches("CL-\\d{3}")) return error("claim_id 형식 오류: " + id);
                    for (JsonElement e : JsonParser.parseString(read("data/claims.json")).getAsJsonArray()) {
                        if (e.getAsJsonObject().get("claimId").getAsString().equals(id)) return GSON.toJson(e);
                    }
                    return error("청구 없음: " + id);
                }
                case "get_policy_clauses": {
                    LocalDate join = LocalDate.parse(str(args, "join_date"));
                    JsonObject policy = JsonParser.parseString(read("data/policy_clauses.json")).getAsJsonObject();
                    for (JsonElement e : policy.getAsJsonArray("versions")) {
                        JsonObject v = e.getAsJsonObject();
                        if (!join.isBefore(LocalDate.parse(v.get("effectiveFrom").getAsString()))
                                && !join.isAfter(LocalDate.parse(v.get("effectiveTo").getAsString()))) {
                            return GSON.toJson(v);
                        }
                    }
                    return error("적용 약관 없음: " + join);
                }
                case "get_customer_contracts": {
                    String id = str(args, "customer_id");
                    if (!id.matches("C\\d{3}")) return error("customer_id 형식 오류: " + id);
                    for (JsonElement e : JsonParser.parseString(read("data/customers.json")).getAsJsonArray()) {
                        JsonObject c = e.getAsJsonObject();
                        if (c.get("customerId").getAsString().equals(id)) return GSON.toJson(c.get("contracts"));
                    }
                    return error("고객 없음: " + id);
                }
                default:
                    return error("구현되지 않은 도구: " + name);
            }
        } catch (Exception e) {
            return error(name + " 실행 실패: " + e.getMessage());
        }
    }

    static String str(JsonObject args, String key) {
        if (!args.has(key) || args.get(key).isJsonNull()) throw new IllegalArgumentException(key + " 누락");
        return args.get(key).getAsString().trim();
    }

    static String error(String msg) {
        JsonObject o = new JsonObject();
        o.addProperty("error", msg);
        return GSON.toJson(o);
    }

    // ---------------- LLM 호출 ----------------

    static JsonObject chat(JsonArray messages, JsonArray tools) throws IOException, InterruptedException {
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        body.add("messages", messages);
        body.add("tools", tools);
        body.addProperty("tool_choice", "auto");
        body.addProperty("temperature", 0.0);
        body.addProperty("max_tokens", 600);
        if (BASE_URL.contains("openrouter.ai")) {
            JsonObject provider = new JsonObject();
            provider.addProperty("require_parameters", true);
            body.add("provider", provider);
        }
        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(90))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) {
            // 400·404면 이 모델·서버가 tools를 지원하지 않을 수 있음
            throw new IOException("HTTP " + response.statusCode() + ": " + response.body());
        }
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    static JsonObject message(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    static String text(JsonObject assistant) {
        return assistant.has("content") && !assistant.get("content").isJsonNull() ? assistant.get("content").getAsString() : "";
    }

    static String head(String s, int n) {
        String one = s.replace("\n", " ");
        return one.length() <= n ? one : one.substring(0, n) + "…";
    }

    static String read(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
