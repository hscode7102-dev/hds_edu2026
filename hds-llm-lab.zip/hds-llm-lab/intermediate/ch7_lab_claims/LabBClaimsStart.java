import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * [7교시 · 종합실습 Ⅱ · 시작 코드] 보상 포탈 — 실손 청구 심사 보조
 *
 * 원칙: 규칙 = Java 코드 / 비정형 해석 = LLM / 최종 판단 = 사람(보상 담당자)
 * 이 파일은 그대로 실행됨. TODO 세 곳을 채워 완성할 것 (막히면 LabBClaimsSolution.java 참고)
 *   TODO 1. lookupVersion : [선택 · 간이 RAG] 가입일에 맞는 약관 버전 조회
 *   TODO 2. validate      : 인용한 조항 ID가 실제로 제공한 조항인지 검증
 *   TODO 3. applyRules    : 가입 초기 청구·보상 제외·통원 한도 등 규칙 판정
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch7_lab_claims/LabBClaimsStart.java [청구ID]
 */
public class LabBClaimsStart {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final boolean USE_CLAUSE_LOOKUP = !"false".equalsIgnoreCase(env("USE_CLAUSE_LOOKUP", "true"));
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    static final List<String> TREATMENT_TYPES = Arrays.asList(
            "입원", "통원", "비급여_도수치료", "비급여_기타", "미용_또는_예방", "판단불가");

    static class ClaimReview {
        String treatmentType;
        String diagnosis;
        List<String> concerns;
        List<String> citedClauses;
    }

    public static void main(String[] args) throws Exception {
        String only = args.length > 0 ? args[0] : null;
        String systemPrompt = read("prompts/claim_system.txt");
        JsonObject schema = JsonParser.parseString(read("schemas/claim_review.schema.json")).getAsJsonObject();
        JsonObject policy = JsonParser.parseString(read("data/policy_clauses.json")).getAsJsonObject();

        for (JsonElement e : JsonParser.parseString(read("data/claims.json")).getAsJsonArray()) {
            JsonObject claim = e.getAsJsonObject();
            if (only != null && !only.equals(claim.get("claimId").getAsString())) continue;
            System.out.println("\n==================== " + claim.get("claimId").getAsString() + " ====================");
            System.out.println(GSON.toJson(review(claim, policy, systemPrompt, schema)));
        }
    }

    static JsonObject review(JsonObject claim, JsonObject policy, String systemPrompt, JsonObject schema) throws Exception {
        JsonObject contract = claim.getAsJsonObject("contract");

        // 1) 약관 조회 — 가입 시점 버전만 (의미 검색이 아니라 정확한 조회)
        JsonObject version = USE_CLAUSE_LOOKUP
                ? lookupVersion(policy, contract.get("productCode").getAsString(), contract.get("joinDate").getAsString())
                : null;
        Map<String, String> clauses = new LinkedHashMap<>();   // 조항 ID → "제목: 본문"
        if (version != null) {
            for (JsonElement c : version.getAsJsonArray("clauses")) {
                JsonObject o = c.getAsJsonObject();
                clauses.put(o.get("id").getAsString(), o.get("title").getAsString() + ": " + o.get("text").getAsString());
            }
        }

        // 2) LLM 해석·인용
        JsonArray messages = new JsonArray();
        messages.add(message("system", systemPrompt));
        messages.add(message("user", buildUserMessage(claim, clauses)));
        String raw = content(chat(messages, schema));
        ClaimReview r = parse(raw);

        // 3) 검증 — 실패하면 1회 복구
        List<String> errors = validate(r, clauses);
        if (!errors.isEmpty()) {
            System.out.println("[검증 실패 → 1회 복구] " + errors);
            messages.add(message("assistant", raw));
            messages.add(message("user", "위 출력에 다음 오류가 있다: " + String.join(", ", errors)
                    + ". 제공된 조항 ID만 인용해 같은 형식의 JSON만 다시 출력하라."));
            raw = content(chat(messages, schema));
            r = parse(raw);
            errors = validate(r, clauses);
        }

        // 4) 규칙 판정 + 5) 담당자 검토용 패키지
        JsonObject out = new JsonObject();
        out.addProperty("claimId", claim.get("claimId").getAsString());
        out.addProperty("appliedPolicyVersion", version == null ? "(조회 안 함)" : version.get("version").getAsString());
        if (!errors.isEmpty()) {
            out.addProperty("status", "AI 정리 실패 — 원본 서류로 직접 심사");
            out.add("validationErrors", GSON.toJsonTree(errors));
            return out;
        }
        out.addProperty("treatmentType", r.treatmentType);
        out.addProperty("diagnosis", r.diagnosis);
        JsonArray cited = new JsonArray();
        for (String id : r.citedClauses) cited.add(id + " " + clauses.get(id));
        out.add("citedClauses", cited);
        out.add("aiConcerns", GSON.toJsonTree(r.concerns));
        out.add("ruleFlags", GSON.toJsonTree(applyRules(claim, r)));
        out.addProperty("decision", "담당자 판단 필요 (AI는 지급 여부를 판단하지 않음)");
        return out;
    }

    /** 상품코드가 같고, 가입일이 적용 기간 안에 있는 버전 하나를 찾음 */
    static JsonObject lookupVersion(JsonObject policy, String productCode, String joinDate) {
        // TODO 1 [선택]: policy의 versions 중 productCode가 같고
        //   effectiveFrom <= joinDate <= effectiveTo 인 버전을 찾아 반환할 것
        //   - 날짜 비교: LocalDate.parse(...), isBefore / isAfter
        //   - 주의: 의미가 비슷한 다른 세대 약관을 쓰면 '근거 있는 오답'이 됨
        return null;   // 지금은 조회하지 않음 → 약관 없이 LLM만으로 처리
    }

    static String buildUserMessage(JsonObject claim, Map<String, String> clauses) {
        JsonObject contract = claim.getAsJsonObject("contract");
        StringBuilder sb = new StringBuilder();
        sb.append("계약: ").append(contract.get("productCode").getAsString())
          .append(" / 가입일 ").append(contract.get("joinDate").getAsString()).append("\n");
        sb.append("청구일: ").append(claim.get("claimDate").getAsString())
          .append(" / 청구금액: ").append(claim.get("amount").getAsLong()).append("원\n\n");
        sb.append("<documents>\n").append(claim.get("documents").getAsString()).append("\n</documents>\n\n");
        sb.append("<clauses>\n");
        if (clauses.isEmpty()) sb.append("(제공된 조항 없음)\n");
        for (Map.Entry<String, String> c : clauses.entrySet()) {
            sb.append("[").append(c.getKey()).append("] ").append(c.getValue()).append("\n");
        }
        return sb.append("</clauses>").toString();
    }

    /** 허용값 + 인용 조항 실재 여부 */
    static List<String> validate(ClaimReview r, Map<String, String> clauses) {
        List<String> errors = new ArrayList<>();
        if (r == null) { errors.add("JSON 파싱 불가"); return errors; }
        if (r.treatmentType == null || !TREATMENT_TYPES.contains(r.treatmentType)) errors.add("treatmentType 허용값 위반: " + r.treatmentType);
        if (r.concerns == null) errors.add("concerns 누락");
        if (r.citedClauses == null) { errors.add("citedClauses 누락"); return errors; }
        // TODO 2: r.citedClauses의 각 ID가 clauses(제공한 조항)에 있는지 확인하고, 없으면 errors에 추가할 것
        return errors;
    }

    /** 정해진 규칙은 Java로 — 아래 기준은 실습용 가상 규칙 */
    static List<String> applyRules(JsonObject claim, ClaimReview r) {
        List<String> flags = new ArrayList<>();
        // TODO 3: 아래 가상 규칙을 Java로 구현할 것
        //   - 가입일~청구일이 90일 이하 → "가입 후 N일 이내 청구 — 고지 확인"
        //       (ChronoUnit.DAYS.between(LocalDate, LocalDate))
        //   - treatmentType이 미용_또는_예방 → 보상 제외 가능
        //   - treatmentType이 통원이고 청구액 > 200,000원 → 회당 한도 확인
        //   - treatmentType이 비급여_도수치료 → 연간 횟수·한도 누적 확인
        //   - 인용 조항이 비어 있음 → 약관 직접 확인
        return flags;
    }

    // ---------------- LLM 호출 ----------------

    static ClaimReview parse(String raw) {
        if (raw == null) return null;
        String s = raw.replace("```json", "").replace("```", "").trim();
        int l = s.indexOf('{'), r = s.lastIndexOf('}');
        if (l < 0 || r <= l) return null;
        try { return GSON.fromJson(s.substring(l, r + 1), ClaimReview.class); } catch (Exception e) { return null; }
    }

    static JsonObject chat(JsonArray messages, JsonObject schema) throws IOException, InterruptedException {
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);
        body.addProperty("max_tokens", 600);
        JsonObject jsonSchema = new JsonObject();
        jsonSchema.addProperty("name", "claim_review");
        jsonSchema.addProperty("strict", true);
        jsonSchema.add("schema", schema);
        JsonObject responseFormat = new JsonObject();
        responseFormat.addProperty("type", "json_schema");
        responseFormat.add("json_schema", jsonSchema);
        body.add("response_format", responseFormat);
        if (BASE_URL.contains("openrouter.ai")) {
            JsonObject provider = new JsonObject();
            provider.addProperty("require_parameters", true);
            body.add("provider", provider);
        }
        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(90))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) throw new IOException("HTTP " + response.statusCode() + ": " + response.body());
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    static JsonObject message(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    static String content(JsonObject res) {
        JsonObject msg = res.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
        return msg.get("content").isJsonNull() ? "" : msg.get("content").getAsString();
    }

    static String read(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
