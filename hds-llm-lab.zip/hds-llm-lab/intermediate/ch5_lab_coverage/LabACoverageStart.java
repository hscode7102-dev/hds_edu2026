import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * [5교시 · 종합실습 Ⅰ · 시작 코드] 설계사 포탈 — 고객 보장 분석
 *
 * 시나리오: 설계사가 상담 전에 고객의 가입 특약을 표준 보장 분류로 정리하고 보장 공백·중복을 파악
 * 이 파일은 그대로 실행됨. TODO 세 곳을 채워 완성할 것 (막히면 LabACoverageSolution.java 참고)
 *   TODO 1. buildUserMessage : 특약 목록을 LLM에 보낼 문자열로 만들기
 *   TODO 2. validate         : 모델 출력 검증 (누락·중복·허용값·범위)
 *   TODO 3. summarize        : 분류별 금액 합산, 보장 공백, 실손 중복 경고
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch5_lab_coverage/LabACoverageStart.java [고객ID]
 */
public class LabACoverageStart {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final double LOW_CONFIDENCE = 0.7;
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    static class Mapping { String riderId; String category; Double confidence; }
    static class MappingResult { List<Mapping> mappings; }

    public static void main(String[] args) throws Exception {
        String customerId = args.length > 0 ? args[0] : "C001";

        // 1) 데이터 조회 (Java)
        JsonObject customer = findCustomer(customerId);
        JsonArray categories = JsonParser.parseString(read("data/coverage_categories.json")).getAsJsonArray();
        Map<String, JsonObject> riders = collectRiders(customer);   // riderId → 특약 정보(+계약번호)
        System.out.println("고객 " + customerId + " / 계약 " + customer.getAsJsonArray("contracts").size()
                + "건 / 특약 " + riders.size() + "개");

        // 2) 특약명 → 보장 분류 매핑 (LLM)
        Set<String> allowed = new HashSet<>();
        for (JsonElement c : categories) allowed.add(c.getAsJsonObject().get("code").getAsString());
        allowed.add("UNKNOWN");

        String systemPrompt = read("prompts/coverage_system.txt").replace("{{CATEGORIES}}", categoryLines(categories));
        JsonObject schema = JsonParser.parseString(read("schemas/coverage_mapping.schema.json")).getAsJsonObject();
        JsonArray messages = new JsonArray();
        messages.add(message("system", systemPrompt));
        messages.add(message("user", buildUserMessage(riders)));

        String raw = content(chat(messages, schema));
        MappingResult result = parse(raw);
        List<String> errors = validate(result, riders.keySet(), allowed);
        if (!errors.isEmpty()) {
            System.out.println("[검증 실패 → 1회 복구] " + errors);
            messages.add(message("assistant", raw));
            messages.add(message("user", "위 출력에 다음 오류가 있다: " + String.join(", ", errors)
                    + ". 모든 riderId를 한 번씩 포함한 같은 형식의 JSON만 다시 출력하라."));
            raw = content(chat(messages, schema));
            result = parse(raw);
            errors = validate(result, riders.keySet(), allowed);
            if (!errors.isEmpty()) {
                System.out.println("복구 실패 — 자동 분석 결과를 제공하지 않음: " + errors);
                return;
            }
        }

        // 3) 금액 합산·공백·중복 판정 (Java)
        JsonObject summary = summarize(customerId, riders, result, categories);
        System.out.println("\n== 설계사 화면용 결과 ==");
        System.out.println(GSON.toJson(summary));
    }

    /** 특약 목록을 'riderId | 특약명' 줄로 — 금액은 매핑에 필요 없으므로 보내지 않음(토큰 절약) */
    static String buildUserMessage(Map<String, JsonObject> riders) {
        // TODO 1: riders의 각 항목을 'riderId | 특약명' 한 줄씩으로 만들어 <riders> 태그로 감쌀 것
        //   - 금액은 매핑에 필요 없으므로 보내지 않음 (토큰 절약)
        //   - 예) C001-R1 | 일반사망보장
        StringBuilder sb = new StringBuilder("특약 목록:\n<riders>\n");
        // 여기에 작성
        return sb.append("</riders>").toString();
    }

    /** 검증: 모든 특약이 정확히 한 번씩, 허용 분류만, 신뢰도 범위 */
    static List<String> validate(MappingResult r, Set<String> riderIds, Set<String> allowed) {
        List<String> errors = new ArrayList<>();
        if (r == null || r.mappings == null) { errors.add("JSON 파싱 불가"); return errors; }
        // TODO 2: 다음 오류를 찾아 errors에 추가할 것
        //   - riderIds에 없는 riderId / 같은 riderId가 두 번 / riderIds 중 누락된 것
        //   - allowed에 없는 category
        //   - confidence가 null이거나 0~1 밖
        return errors;
    }

    /** 분류별 합산 + 보장 공백 + 실손 중복 + 확인 필요 특약 */
    static JsonObject summarize(String customerId, Map<String, JsonObject> riders, MappingResult r, JsonArray categories) {
        JsonObject out = new JsonObject();
        out.addProperty("customerId", customerId);
        // TODO 3: 아래 항목을 계산해 out에 추가할 것
        //   - coverageByCategory: 분류별 totalAmount(특약 금액 합)와 riders 목록 (categories 순서대로)
        //   - gaps: 매핑된 특약이 하나도 없는 분류 이름 목록
        //   - warnings: MEDICAL(실손의료비)이 서로 다른 계약 2개 이상에 있으면 중복 가입 경고
        //   - needCheck: UNKNOWN이거나 confidence < LOW_CONFIDENCE 인 특약
        //   힌트: riders.get(m.riderId)에 amount, name, contractNo가 들어 있음
        out.add("mappings", GSON.toJsonTree(r.mappings));   // 임시: 매핑 결과만 출력
        return out;
    }

    // ---------------- 데이터 ----------------

    static JsonObject findCustomer(String customerId) throws IOException {
        for (JsonElement e : JsonParser.parseString(read("data/customers.json")).getAsJsonArray()) {
            if (e.getAsJsonObject().get("customerId").getAsString().equals(customerId)) return e.getAsJsonObject();
        }
        throw new IllegalArgumentException("고객 없음: " + customerId);
    }

    static Map<String, JsonObject> collectRiders(JsonObject customer) {
        Map<String, JsonObject> riders = new LinkedHashMap<>();
        for (JsonElement ce : customer.getAsJsonArray("contracts")) {
            JsonObject contract = ce.getAsJsonObject();
            for (JsonElement re : contract.getAsJsonArray("riders")) {
                JsonObject rider = re.getAsJsonObject().deepCopy();
                rider.addProperty("contractNo", contract.get("contractNo").getAsString());
                riders.put(rider.get("riderId").getAsString(), rider);
            }
        }
        return riders;
    }

    static String categoryLines(JsonArray categories) {
        StringBuilder sb = new StringBuilder();
        for (JsonElement e : categories) {
            JsonObject c = e.getAsJsonObject();
            sb.append("- ").append(c.get("code").getAsString()).append(": ").append(c.get("name").getAsString())
              .append(" — ").append(c.get("desc").getAsString()).append("\n");
        }
        return sb.append("- UNKNOWN: 특약 이름만으로 판단 불가").toString();
    }

    // ---------------- LLM 호출 (Step06과 동일한 방식) ----------------

    static MappingResult parse(String raw) {
        if (raw == null) return null;
        String s = raw.replace("```json", "").replace("```", "").trim();
        int l = s.indexOf('{'), r = s.lastIndexOf('}');
        if (l < 0 || r <= l) return null;
        try { return GSON.fromJson(s.substring(l, r + 1), MappingResult.class); } catch (Exception e) { return null; }
    }

    static JsonObject chat(JsonArray messages, JsonObject schema) throws IOException, InterruptedException {
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);
        body.addProperty("max_tokens", 800);
        JsonObject jsonSchema = new JsonObject();
        jsonSchema.addProperty("name", "coverage_mapping");
        jsonSchema.addProperty("strict", true);
        jsonSchema.add("schema", schema);
        JsonObject responseFormat = new JsonObject();
        responseFormat.addProperty("type", "json_schema");
        responseFormat.add("json_schema", jsonSchema);
        body.add("response_format", responseFormat);
        if (BASE_URL.contains("openrouter.ai")) {
            JsonObject provider = new JsonObject();
            provider.addProperty("require_parameters", true);
            body.add("provider", provider);
        }
        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(90))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) throw new IOException("HTTP " + response.statusCode() + ": " + response.body());
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    static JsonObject message(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    static String content(JsonObject res) {
        JsonObject msg = res.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
        return msg.get("content").isJsonNull() ? "" : msg.get("content").getAsString();
    }

    static String read(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
