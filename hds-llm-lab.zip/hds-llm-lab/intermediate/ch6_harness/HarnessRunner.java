import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.annotations.SerializedName;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * [6교시 · 하네스] 테스트셋으로 프롬프트를 측정하고 실패를 기록
 *
 * 하네스 고리: 실패 로그 → 가설 → 재현(테스트셋) → 프롬프트 수정 → 커밋 → 다시 측정
 *
 * 3단계 검증
 *   ① 스키마 : JSON 파싱, 필수 필드, 허용값, 범위
 *   ② 구조   : 필드 간 규칙 (REVIEW면 needs_review=true, 신뢰도 낮으면 needs_review=true)
 *   ③ 반례   : 기대 팀과 비교 (경계·반례·정보부족·주입 태그별 정확도)
 *
 * 결과
 *   - logs/failures_<버전>_<시각>.jsonl : 실패 사례 한 줄씩 (요청 ID, 단계, 원인)
 *   - logs/summary_<버전>.json          : 지표 요약 → Git에 커밋해 버전별로 비교
 *
 * 환경변수: PROMPT_FILE(기본 prompts/team_system.txt), PROMPT_VERSION(기본 v1), USE_JSON_SCHEMA, SLEEP_MS(기본 300)
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch6_harness/HarnessRunner.java
 */
public class HarnessRunner {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final String PROMPT_FILE = env("PROMPT_FILE", "prompts/team_system.txt");
    static final String PROMPT_VERSION = env("PROMPT_VERSION", "v1");
    static final boolean USE_JSON_SCHEMA = !"false".equalsIgnoreCase(env("USE_JSON_SCHEMA", "true"));
    static final long SLEEP_MS = Long.parseLong(env("SLEEP_MS", "300"));   // 30명 동시 실습 시 호출 몰림 완화
    static final double REVIEW_THRESHOLD = 0.70;
    static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();
    static final Gson PRETTY = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    static final List<String> ALLOWED_TEAMS = Arrays.asList(
            "장기계약팀", "장기유지팀", "손사지원팀", "자동차보험팀", "자동차보상팀", "일반보험팀",
            "마케팅팀", "정보계지원팀", "콜센터팀", "홈페이지모바일팀", "개발지원팀", "REVIEW");

    static class Result {
        String team;
        String reason;
        Double confidence;
        @SerializedName("needs_review") Boolean needsReview;
    }

    public static void main(String[] args) throws Exception {
        String systemPrompt = read(PROMPT_FILE);
        JsonObject schema = JsonParser.parseString(read("schemas/team_routing.schema.json")).getAsJsonObject();
        JsonArray testset = JsonParser.parseString(read("data/testset_team_routing.json")).getAsJsonArray();

        Files.createDirectories(Paths.get("logs"));
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        Path failLog = Paths.get("logs", "failures_" + PROMPT_VERSION + "_" + stamp + ".jsonl");

        int schemaOk = 0, structureOk = 0, correct = 0, reviewExpected = 0, reviewHit = 0, totalTokens = 0;
        List<Long> latencies = new ArrayList<>();
        Map<String, int[]> byTag = new LinkedHashMap<>();   // tag → {정답 수, 전체 수}

        System.out.println("프롬프트 " + PROMPT_FILE + " (" + PROMPT_VERSION + ") / 모델 " + MODEL + " / 테스트 " + testset.size() + "건");
        for (JsonElement e : testset) {
            JsonObject t = e.getAsJsonObject();
            String id = t.get("id").getAsString();
            String tag = t.get("tag").getAsString();
            String expected = t.get("expected").getAsString();
            byTag.computeIfAbsent(tag, k -> new int[2])[1]++;

            long start = System.currentTimeMillis();
            String raw;
            JsonObject res;
            try {
                res = chat(systemPrompt, schema, t.get("text").getAsString());
                raw = content(res);
            } catch (IOException ex) {
                appendFailure(failLog, id, tag, "호출", ex.getMessage(), null, expected);
                System.out.println("E " + id + " 호출 실패: " + ex.getMessage());
                continue;
            }
            latencies.add(System.currentTimeMillis() - start);
            if (res.has("usage")) totalTokens += res.getAsJsonObject("usage").get("total_tokens").getAsInt();

            // ① 스키마
            Result r = parse(raw);
            List<String> schemaErrors = checkSchema(r);
            if (!schemaErrors.isEmpty()) {
                appendFailure(failLog, id, tag, "①스키마", String.join(", ", schemaErrors), raw, expected);
                System.out.println("X " + id + " [①스키마] " + schemaErrors);
                continue;
            }
            schemaOk++;

            // ② 구조
            List<String> structureErrors = checkStructure(r);
            if (structureErrors.isEmpty()) structureOk++;
            else appendFailure(failLog, id, tag, "②구조", String.join(", ", structureErrors), raw, expected);

            // ③ 반례·정답 비교
            boolean ok = expected.equals(r.team);
            if (ok) { correct++; byTag.get(tag)[0]++; }
            else appendFailure(failLog, id, tag, "③정답불일치", "기대 " + expected + " / 결과 " + r.team, raw, expected);
            if ("REVIEW".equals(expected)) { reviewExpected++; if ("REVIEW".equals(r.team)) reviewHit++; }

            System.out.printf("%s %-3s %-4s 기대=%-8s 결과=%-8s conf=%.2f%s%n", ok ? "O" : "X", id, tag, expected, r.team,
                    r.confidence, structureErrors.isEmpty() ? "" : " [②구조] " + structureErrors);
            Thread.sleep(SLEEP_MS);
        }

        // 지표 요약
        int n = testset.size();
        JsonObject summary = new JsonObject();
        summary.addProperty("promptVersion", PROMPT_VERSION);
        summary.addProperty("promptFile", PROMPT_FILE);
        summary.addProperty("model", MODEL);
        summary.addProperty("jsonSchema", USE_JSON_SCHEMA);
        summary.addProperty("runAt", stamp);
        summary.addProperty("cases", n);
        summary.addProperty("schemaPassRate", ratio(schemaOk, n));
        summary.addProperty("structurePassRate", ratio(structureOk, n));
        summary.addProperty("accuracy", ratio(correct, n));
        summary.addProperty("reviewRecall", reviewExpected == 0 ? "-" : ratio(reviewHit, reviewExpected));
        summary.addProperty("avgTotalTokens", latencies.isEmpty() ? 0 : totalTokens / latencies.size());
        summary.addProperty("p95LatencyMs", p95(latencies));
        JsonObject tags = new JsonObject();
        for (Map.Entry<String, int[]> en : byTag.entrySet()) tags.addProperty(en.getKey(), en.getValue()[0] + "/" + en.getValue()[1]);
        summary.add("accuracyByTag", tags);

        Path summaryFile = Paths.get("logs", "summary_" + PROMPT_VERSION + ".json");
        Files.write(summaryFile, PRETTY.toJson(summary).getBytes(StandardCharsets.UTF_8));
        System.out.println("\n== 요약 ==\n" + PRETTY.toJson(summary));
        System.out.println("\n실패 로그: " + failLog + (Files.exists(failLog) ? "" : " (실패 없음)"));
        System.out.println("요약 파일: " + summaryFile + " → 프롬프트 파일과 함께 커밋해 버전별로 비교");
    }

    static List<String> checkSchema(Result r) {
        List<String> errors = new ArrayList<>();
        if (r == null) { errors.add("JSON 파싱 불가"); return errors; }
        if (r.team == null || !ALLOWED_TEAMS.contains(r.team)) errors.add("team 허용값 위반: " + r.team);
        if (r.reason == null || r.reason.trim().isEmpty()) errors.add("reason 누락");
        else if (r.reason.length() > 40) errors.add("reason 40자 초과");
        if (r.confidence == null || r.confidence < 0 || r.confidence > 1) errors.add("confidence 범위 위반");
        if (r.needsReview == null) errors.add("needs_review 누락");
        return errors;
    }

    static List<String> checkStructure(Result r) {
        List<String> errors = new ArrayList<>();
        if ("REVIEW".equals(r.team) && !Boolean.TRUE.equals(r.needsReview)) errors.add("REVIEW인데 needs_review=false");
        if (r.confidence < REVIEW_THRESHOLD && !Boolean.TRUE.equals(r.needsReview)) errors.add("신뢰도 낮은데 needs_review=false");
        if (!"REVIEW".equals(r.team) && r.confidence >= 0.99) errors.add("과신 의심(confidence≥0.99)");
        return errors;
    }

    /** 실패 한 건을 한 줄 JSON으로 추가. 원문은 200자로 잘라 저장 (전문 무기한 저장 금지) */
    static void appendFailure(Path file, String id, String tag, String stage, String cause, String raw, String expected) throws IOException {
        JsonObject line = new JsonObject();
        line.addProperty("id", id);
        line.addProperty("tag", tag);
        line.addProperty("stage", stage);
        line.addProperty("cause", cause);
        line.addProperty("expected", expected);
        line.addProperty("promptVersion", PROMPT_VERSION);
        if (raw != null) line.addProperty("rawHead", raw.length() > 200 ? raw.substring(0, 200) : raw);
        Files.write(file, (GSON.toJson(line) + "\n").getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    static String ratio(int a, int b) { return a + "/" + b + " (" + Math.round(100.0 * a / b) + "%)"; }

    static long p95(List<Long> xs) {
        if (xs.isEmpty()) return 0;
        List<Long> s = new ArrayList<>(xs);
        Collections.sort(s);
        return s.get((int) Math.ceil(0.95 * s.size()) - 1);
    }

    static Result parse(String raw) {
        if (raw == null) return null;
        String s = raw.replace("```json", "").replace("```", "").trim();
        int l = s.indexOf('{'), r = s.lastIndexOf('}');
        if (l < 0 || r <= l) return null;
        try { return GSON.fromJson(s.substring(l, r + 1), Result.class); } catch (Exception e) { return null; }
    }

    static JsonObject chat(String systemPrompt, JsonObject schema, String requestText) throws IOException, InterruptedException {
        JsonArray messages = new JsonArray();
        messages.add(message("system", systemPrompt));
        messages.add(message("user", "<request>\n" + requestText + "\n</request>"));
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);
        body.addProperty("max_tokens", 300);
        if (USE_JSON_SCHEMA) {
            JsonObject jsonSchema = new JsonObject();
            jsonSchema.addProperty("name", "team_routing");
            jsonSchema.addProperty("strict", true);
            jsonSchema.add("schema", schema);
            JsonObject responseFormat = new JsonObject();
            responseFormat.addProperty("type", "json_schema");
            responseFormat.add("json_schema", jsonSchema);
            body.add("response_format", responseFormat);
            if (BASE_URL.contains("openrouter.ai")) {
                JsonObject provider = new JsonObject();
                provider.addProperty("require_parameters", true);
                body.add("provider", provider);
            }
        }
        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) throw new IOException("HTTP " + response.statusCode());
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    static JsonObject message(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    static String content(JsonObject res) {
        JsonObject msg = res.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
        return msg.get("content").isJsonNull() ? "" : msg.get("content").getAsString();
    }

    static String read(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
