import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

/**
 * [3교시 · 실습 3] 전산작업의뢰 → 담당 팀 분류 (Zero-shot vs Few-shot)
 * - 프롬프트는 코드가 아니라 prompts/*.txt 파일에 둠 → 수정·버전관리(6교시)가 쉬움
 * - data/requests.json 10건을 두 프롬프트로 각각 분류해 정확도·토큰을 비교
 * - 모델 출력은 아직 형식이 보장되지 않음 → 관대하게 파싱(코드펜스 제거, 팀명 검색)
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch3_prompting/Step05Prompting.java
 *       (인자: zero 또는 few 로 한쪽만 실행 가능)
 */
public class Step05Prompting {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final Gson GSON = new Gson();
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    static final List<String> TEAMS = Arrays.asList(
            "장기계약팀", "장기유지팀", "손사지원팀", "자동차보험팀", "자동차보상팀", "일반보험팀",
            "마케팅팀", "정보계지원팀", "콜센터팀", "홈페이지모바일팀", "개발지원팀", "REVIEW");

    public static void main(String[] args) throws Exception {
        JsonArray requests = JsonParser.parseString(read("data/requests.json")).getAsJsonArray();
        String only = args.length > 0 ? args[0] : "both";

        if (!only.equals("few")) run("Zero-shot", read("prompts/team_zero_shot.txt"), requests);
        if (!only.equals("zero")) run("Few-shot", read("prompts/team_few_shot.txt"), requests);
    }

    static void run(String label, String template, JsonArray requests) throws Exception {
        System.out.println("\n== " + label + " ==");
        int correct = 0, totalPrompt = 0, totalCompletion = 0;
        for (JsonElement e : requests) {
            JsonObject r = e.getAsJsonObject();
            String prompt = template.replace("{{REQUEST_TEXT}}", r.get("text").getAsString());
            JsonObject res = chat(prompt);
            String raw = content(res);
            String team = extractTeam(raw);
            String expected = r.get("expected").getAsString();
            boolean ok = expected.equals(team);
            if (ok) correct++;
            JsonObject usage = res.getAsJsonObject("usage");
            if (usage != null) {
                totalPrompt += usage.get("prompt_tokens").getAsInt();
                totalCompletion += usage.get("completion_tokens").getAsInt();
            }
            System.out.printf("%s %-4s 기대=%-8s 결과=%-8s | 원문: %s%n",
                    ok ? "O" : "X", r.get("id").getAsString(), expected, team, oneLine(raw, 50));
        }
        int n = requests.size();
        System.out.printf("→ 정확도 %d/%d, 평균 입력 토큰 %d, 평균 출력 토큰 %d%n",
                correct, n, totalPrompt / n, totalCompletion / n);
    }

    /** 관대한 파싱: 코드펜스 제거 → JSON이면 team 필드 → 아니면 허용 팀명이 처음 등장하는 것 */
    static String extractTeam(String raw) {
        String s = raw.replace("```json", "").replace("```", "").trim();
        int l = s.indexOf('{'), r = s.lastIndexOf('}');
        if (l >= 0 && r > l) {
            try {
                JsonObject o = JsonParser.parseString(s.substring(l, r + 1)).getAsJsonObject();
                if (o.has("team")) return o.get("team").getAsString().trim();
            } catch (Exception ignore) {
                // JSON이 아니면 아래 문자열 검색으로
            }
        }
        String best = "파싱실패";
        int bestPos = Integer.MAX_VALUE;
        for (String t : TEAMS) {
            int p = s.indexOf(t);
            if (p >= 0 && p < bestPos) { best = t; bestPos = p; }
        }
        return best;
    }

    static JsonObject chat(String userText) throws IOException, InterruptedException {
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        JsonArray messages = new JsonArray();
        JsonObject m = new JsonObject();
        m.addProperty("role", "user");
        m.addProperty("content", userText);
        messages.add(m);
        body.add("messages", messages);
        body.addProperty("temperature", 0.0);   // 분류는 낮은 temperature
        body.addProperty("max_tokens", 200);

        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (response.statusCode() != 200) throw new IOException("HTTP " + response.statusCode() + ": " + response.body());
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    static String content(JsonObject res) {
        JsonObject msg = res.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
        return msg.get("content").isJsonNull() ? "" : msg.get("content").getAsString();
    }

    static String read(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }

    static String oneLine(String s, int n) {
        String one = s.replace("\n", " ").trim();
        return one.length() <= n ? one : one.substring(0, n) + "…";
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
