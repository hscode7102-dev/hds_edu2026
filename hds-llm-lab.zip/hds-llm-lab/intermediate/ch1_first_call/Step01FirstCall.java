import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * [1교시 · 실습 1-1] 첫 API 호출
 * - 요청 JSON 만들기 → POST → 응답 JSON에서 답변(content)과 토큰 사용량(usage) 꺼내기
 *
 * 실행: java -Dfile.encoding=UTF-8 -cp lib/gson-2.10.1.jar intermediate/ch1_first_call/Step01FirstCall.java
 */
public class Step01FirstCall {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    public static void main(String[] args) throws Exception {
        String question = args.length > 0 ? args[0] : "실손보험이 무엇인지 두 문장으로 설명해줘.";

        // 1) 요청 JSON 만들기: model + messages(역할과 내용) + 파라미터
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        JsonArray messages = new JsonArray();
        messages.add(message("user", question));
        body.add("messages", messages);
        body.addProperty("temperature", 0.2);
        body.addProperty("max_tokens", 300);

        System.out.println("== 요청 ==");
        System.out.println(GSON.toJson(body));

        // 2) HTTP POST
        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + "/chat/completions"))
                .timeout(Duration.ofSeconds(60))
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));

        System.out.println("\n== 응답 원문 (HTTP " + response.statusCode() + ") ==");
        if (response.statusCode() != 200) {
            System.out.println(response.body());
            return;
        }
        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        System.out.println(GSON.toJson(json));

        // 3) 필요한 값 꺼내기: choices[0].message.content / finish_reason / usage
        JsonObject choice = json.getAsJsonArray("choices").get(0).getAsJsonObject();
        String content = choice.getAsJsonObject("message").get("content").getAsString();
        String finishReason = choice.has("finish_reason") && !choice.get("finish_reason").isJsonNull()
                ? choice.get("finish_reason").getAsString() : "(없음)";
        JsonObject usage = json.getAsJsonObject("usage");

        System.out.println("\n== 꺼낸 값 ==");
        System.out.println("답변          : " + content);
        System.out.println("finish_reason : " + finishReason);
        if (usage != null) {
            System.out.println("입력 토큰     : " + usage.get("prompt_tokens"));
            System.out.println("출력 토큰     : " + usage.get("completion_tokens"));
        }
    }

    static JsonObject message(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
