import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * [부록] Java 8 환경용 첫 호출 — HttpURLConnection 버전
 * - Step01FirstCall과 같은 일을 Java 8 표준 기능만으로 수행
 * - 회사 운영 환경이 Java 8이면 실습 코드의 HttpClient 부분을 이 방식으로 바꿔 끼우면 됨
 *   (나머지 JSON 처리·검증 코드는 Java 8 문법으로 작성되어 있음)
 *
 * Java 8에는 단일 파일 실행이 없으므로 컴파일 후 실행 (Windows는 클래스패스 구분자가 ';')
 *   javac -encoding UTF-8 -cp lib/gson-2.10.1.jar -d out appendix_java8/Java8FirstCall.java
 *   java -cp "out;lib/gson-2.10.1.jar" Java8FirstCall
 */
public class Java8FirstCall {

    static final String API_KEY = env("API_KEY", "");
    static final String BASE_URL = env("BASE_URL", "https://openrouter.ai/api/v1");
    static final String MODEL = env("MODEL", "google/gemma-4-26b-a4b-it");

    public static void main(String[] args) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        JsonArray messages = new JsonArray();
        JsonObject m = new JsonObject();
        m.addProperty("role", "user");
        m.addProperty("content", "실손보험이 무엇인지 두 문장으로 설명해줘.");
        messages.add(m);
        body.add("messages", messages);
        body.addProperty("temperature", 0.2);
        body.addProperty("max_tokens", 300);

        String response = post(BASE_URL + "/chat/completions", new Gson().toJson(body));
        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
        String content = json.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content").getAsString();
        System.out.println("답변: " + content);
        System.out.println("usage: " + json.get("usage"));
    }

    /** Java 8: HttpURLConnection으로 POST. 연결·읽기 timeout을 따로 지정해야 함 */
    static String post(String url, String json) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(10_000);
        conn.setReadTimeout(60_000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Authorization", "Bearer " + API_KEY);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        try (OutputStream os = conn.getOutputStream()) {
            os.write(json.getBytes(StandardCharsets.UTF_8));
        }
        int status = conn.getResponseCode();
        InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
        String text = readAll(is);
        conn.disconnect();
        if (status != 200) throw new IOException("HTTP " + status + ": " + text);
        return text;
    }

    static String readAll(InputStream is) throws IOException {
        if (is == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
        is.close();
        return new String(bos.toByteArray(), StandardCharsets.UTF_8);
    }

    static String env(String name, String def) {
        String v = System.getenv(name);
        return (v == null || v.trim().isEmpty()) ? def : v.trim();
    }
}
